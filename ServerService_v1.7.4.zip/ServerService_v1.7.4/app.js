// ServerService v1.7.3 — local-only build, no external API services.
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

function setTheme(theme) {
  document.body.dataset.theme = theme;
  $("#themeToggle").textContent = theme === "dark" ? "\u263C" : "\u263E";
  $("#themeToggleSettings").textContent = theme === "dark" ? "밝은 테마로 전환" : "어두운 테마로 전환";
  localStorage.setItem("serverservice_theme", theme);
}
function toggleTheme() { setTheme(document.body.dataset.theme === "dark" ? "light" : "dark"); }
$("#themeToggle").addEventListener("click", toggleTheme);
$("#themeToggleSettings").addEventListener("click", toggleTheme);

const pageTitles = { dashboard: "대시보드", programs: "프로그램", system: "시스템", network: "네트워크", audio: "오디오 모니터링", devices: "장치 튜닝", extensions: "확장프로그램", settings: "설정" };
function showPage(name) {
  $$(".page").forEach(p => p.classList.toggle("active", p.id === `page-${name}`));
  $$(".nav-item[data-page]").forEach(i => i.classList.toggle("active", i.dataset.page === name));
  document.title = `ServerService | ${pageTitles[name] || "대시보드"}`;
  window.scrollTo({ top: 0, behavior: "smooth" });
}
$$(".nav-item[data-page]").forEach(i => i.addEventListener("click", () => showPage(i.dataset.page)));
$$("[data-goto]").forEach(b => b.addEventListener("click", () => showPage(b.dataset.goto)));

function updateClock() {
  $("#clock").textContent = new Intl.DateTimeFormat("ko-KR", { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }).format(new Date());
}
updateClock();
setInterval(updateClock, 1000);

let refreshTimer = null;
const networkHistory = [];
async function refreshMetrics(silent = false) {
  await loadSystemData();
  if (!silent) {
    const status = $("#systemStatus");
    if (status && status.textContent.includes("연결")) {
      status.textContent = "실제 시스템 정보를 갱신했습니다.";
    }
  }
}
$("#refreshButton").addEventListener("click", () => refreshMetrics(false));

$$(".tab[data-tab]").forEach(t => {
  t.addEventListener("click", () => {
    $$(".tab[data-tab]").forEach(i => i.classList.toggle("active", i === t));
    ["running", "blocked", "installed", "startup"].forEach(n => {
      const e = $(`#${n}Tab`);
      if (e) e.classList.toggle("hidden", t.dataset.tab !== n);
    });
  });
});

function bindSearch(id, sel) {
  const i = $(`#${id}`);
  if (!i) return;
  i.addEventListener("input", e => {
    const q = e.target.value.trim().toLowerCase();
    $$(sel).forEach(r => r.classList.toggle("hidden", !r.textContent.toLowerCase().includes(q)));
  });
}
bindSearch("processSearch", ".searchable");
bindSearch("startupSearch", ".startup-row");
bindSearch("extensionSearch", ".extension-card");

const modalBackdrop = $("#modalBackdrop");
const modalTitle = $("#modalTitle");
const modalBody = $("#modalBody");
function openModal(title, html) {
  modalTitle.textContent = title;
  modalBody.innerHTML = html;
  modalBackdrop.classList.remove("hidden");
  modalBackdrop.setAttribute("aria-hidden", "false");
}
function closeModal() {
  if (document.activeElement && modalBackdrop.contains(document.activeElement)) document.activeElement.blur();
  modalBackdrop.classList.add("hidden");
  modalBackdrop.setAttribute("aria-hidden", "true");
}
$("#modalClose").addEventListener("click", closeModal);
modalBackdrop.addEventListener("click", e => { if (e.target === modalBackdrop) closeModal(); });
document.addEventListener("keydown", e => { if (e.key === "Escape" && !modalBackdrop.classList.contains("hidden")) closeModal(); });

const detailData = {
  cpu: { title: "CPU 상세 정보", html: () => `<p class="muted">CPU 정보를 불러오는 중입니다.</p>` },
  gpu: { title: "GPU 상세 정보", html: () => `<p class="muted">GPU 정보를 불러오는 중입니다.</p>` },
  memory: { title: "메모리 상세 정보", html: () => `<p class="muted">메모리 정보를 불러오는 중입니다.</p>` },
  disk: { title: "디스크 상세 정보", html: () => `<p class="muted">디스크 정보를 불러오는 중입니다.</p>` }
};
$$(".gauge-item[data-detail]").forEach(item => {
  const open = () => { const d = detailData[item.dataset.detail]; if (d) openModal(d.title, d.html()); };
  item.addEventListener("click", open);
  item.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); open(); } });
});

$("#diagnoseButton").addEventListener("click", async () => {
  const result = $("#diagnosticResult");
  const steps = $("#diagnosticSteps");
  result.textContent = "진단을 실행 중입니다...";
  result.style.color = "var(--muted)";
  steps.innerHTML = "";
  const list = ["네트워크 어댑터 확인", "IP 구성 확인", "기본 게이트웨이 Ping", "DNS 확인", "인터넷 연결 확인"];
  for (const item of list) {
    const step = document.createElement("div");
    step.className = "diagnostic-step";
    step.innerHTML = `<span class="step-dot"></span><span>${item}</span>`;
    steps.appendChild(step);
    await new Promise(r => setTimeout(r, 450));
    step.classList.add("done");
  }
  try {
    const response = await fetch("/api/system", { cache: "no-store" });
    if (!response.ok) throw new Error("진단 정보를 가져오지 못했습니다.");
    const data = await response.json();
    const net = data.network || {};
    result.textContent = `진단 완료: 어댑터 ${net.adapter || "확인 불가"} · IPv4 ${net.ip || "확인 불가"} · 게이트웨이 ${net.gateway || "확인 불가"}. DNS/인터넷 연결의 실제 성공 여부는 별도 검사해야 합니다.`;
    result.style.color = "var(--green)";
  } catch (e) {
    result.textContent = "진단 실패: 로컬 시스템 서비스에 연결할 수 없습니다. start.bat으로 실행했는지 확인하세요.";
    result.style.color = "var(--orange)";
  }
});

function tryOpenSettings(uri, msg) {
  try {
    const w = window.open(uri, "_blank");
    if (!w) throw new Error("blocked");
  } catch (e) {
    openModal("설정 열기 안내", `<p class="muted">${msg}</p><div class="detail-row"><span>URI</span><strong>${uri}</strong></div>`);
  }
}
$("#openIpSettings").addEventListener("click", () => tryOpenSettings("ms-settings:network-proxy", "Windows IP/프록시 설정 화면을 엽니다."));
$("#openNetworkSettings").addEventListener("click", () => tryOpenSettings("ms-settings:network", "Windows 네트워크 설정 화면을 엽니다."));
$("#changeIpType").addEventListener("click", () => {
  openModal("IP 주소 유형 변경", `
    <div class="setting-row" style="border:1px solid var(--border);border-radius:9px;padding:10px 12px;"><div><strong>DHCP (자동)</strong><p class="muted">IP를 자동으로 할당받습니다.</p></div><input type="radio" name="ipType" value="dhcp" checked></div>
    <div class="setting-row" style="border:1px solid var(--border);border-radius:9px;padding:10px 12px;"><div><strong>고정 IP (수동)</strong><p class="muted">IP를 직접 입력합니다.</p></div><input type="radio" name="ipType" value="static"></div>
    <div class="detail-row"><span>IPv4 주소</span><input id="staticIp" value="192.168.0.42" style="background:var(--bg);border:1px solid var(--border);color:var(--text);border-radius:6px;padding:4px 8px;"></div>
    <div class="detail-row"><span>서브넷</span><input id="staticMask" value="255.255.255.0" style="background:var(--bg);border:1px solid var(--border);color:var(--text);border-radius:6px;padding:4px 8px;"></div>
    <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:6px;"><button class="button secondary" id="cancelIp">취소</button><button class="button primary" id="saveIp">적용</button></div>
  `);
  $("#cancelIp").addEventListener("click", closeModal);
  $("#saveIp").addEventListener("click", () => {
    const selected = document.querySelector('input[name="ipType"]:checked');
    const mode = selected && selected.value === "static" ? "고정 IP (수동)" : "DHCP (자동)";
    $("#ipModeLabel").textContent = mode;
    closeModal();
    $("#systemStatus").textContent = `IP 할당 방식이 ${mode}(으)로 변경되었습니다.`;
    setTimeout(() => $("#systemStatus").textContent = "시스템이 정상적으로 동작 중입니다.", 2500);
  });
});

function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c])); }
let extensionItems = [];
async function renderExtensions() {
  const container = $("#extensionsList"), empty = $("#extensionsEmpty");
  if (!container || !empty) return;
  try {
    const inboxRes = await fetch("/api/extensions/import-folder", { method: "POST", cache: "no-store" }).catch(() => null);
    if (inboxRes?.ok) {
      const inboxData = await inboxRes.json().catch(() => null);
      for (const item of (inboxData?.results || [])) {
        if (!item.success) {
          const key = `${item.filename}:${item.message}`;
          if (!reportedInboxErrors.has(key)) { reportedInboxErrors.add(key); showExtensionUploadStatus(`${item.filename}: ${item.message}`, true); }
        } else {
          showExtensionUploadStatus(`폴더에서 자동 등록: ${item.name} v${item.version}`);
        }
      }
    }
    const res = await fetch("/api/extensions", { cache: "no-store" });
    if (!res.ok) throw new Error("목록 조회 실패");
    extensionItems = await res.json();
  } catch (_) { extensionItems = []; }
  container.replaceChildren();
  const q = ($("#extensionSearch")?.value || "").trim().toLowerCase();
  const filtered = extensionItems.filter(e => !q || String(e.name).toLowerCase().includes(q));
  const hasExtensions = extensionItems.length > 0;

  if (!hasExtensions) { empty.style.display = "grid"; return; }
  empty.style.display = filtered.length ? "none" : "grid";
  if (!filtered.length) { empty.querySelector("strong").textContent = "검색 결과가 없습니다."; empty.querySelector("p").textContent = "검색어를 바꿔 다시 시도하세요."; return; }
  filtered.forEach(ext => {
    const card = document.createElement("article"); card.className = "extension-card";
    const size = Number(ext.size || 0);
    const activeKey = `serverservice_extension_enabled_${ext.id || ext.filename}`;
    let enabled = true; try { enabled = localStorage.getItem(activeKey) !== "false"; } catch (_) {}
    card.innerHTML = `<div class="ext-icon">♫</div><div class="ext-info"><strong>${escapeHtml(ext.name)}</strong><span>v${escapeHtml(ext.version)} · ${(size/1024).toFixed(1)} KB · ${escapeHtml(ext.uploadedAt || "등록됨")}</span><span class="tiny-note">패키지 상태만 관리합니다. ZIP 코드는 이 대시보드에서 자동 실행하지 않습니다.</span></div><span class="ext-state ${enabled ? "on" : "off"}">${enabled ? "활성화" : "비활성화"}</span><div class="ext-actions"><label class="module-switch"><input type="checkbox" data-extension-toggle ${enabled ? "checked" : ""}><span>활성화</span></label><button class="button secondary" type="button" data-extension-download ${enabled ? "" : "disabled"}>ZIP 다운로드</button></div>`;
    card.querySelector("[data-extension-toggle]").addEventListener("change", e => { try { localStorage.setItem(activeKey, String(e.target.checked)); } catch (_) {} renderExtensions(); });
    card.querySelector("[data-extension-download]").addEventListener("click", () => { if (!enabled) return; const a = document.createElement("a"); a.href = ext.fileUrl; a.download = ext.filename || "extension.zip"; document.body.appendChild(a); a.click(); a.remove(); });
    container.appendChild(card);
  });
}
$("#extensionSearch")?.addEventListener("input", () => renderExtensions());

const extensionDropZone = $("#extensionDropZone");
const extensionUploadInput = $("#extensionUploadInput");
const extensionUploadQueue = $("#extensionUploadQueue");
const reportedInboxErrors = new Set();
function showExtensionUploadStatus(message, isError = false) {
  if (!extensionUploadQueue) return;
  const line = document.createElement("p");
  line.className = `extension-upload-result${isError ? " error" : ""}`;
  line.textContent = message;
  extensionUploadQueue.prepend(line);
}
async function uploadExtensionFiles(fileList) {
  const files = Array.from(fileList || []);
  if (!files.length) return;
  for (const file of files) {
    if (!file.name.toLowerCase().endsWith(".zip")) { showExtensionUploadStatus(`${file.name}: ZIP 파일만 업로드할 수 있습니다.`, true); continue; }
    if (file.size <= 0 || file.size > 100 * 1024 * 1024) { showExtensionUploadStatus(`${file.name}: 파일 크기는 1바이트~100MB여야 합니다.`, true); continue; }
    showExtensionUploadStatus(`${file.name}: 업로드 및 manifest 검사 중…`);
    try {
      const res = await fetch(`/api/extensions/upload?filename=${encodeURIComponent(file.name)}`, { method: "POST", headers: { "Content-Type": "application/octet-stream" }, body: file, cache: "no-store" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "업로드 실패");
      showExtensionUploadStatus(`등록 완료: ${data.name} v${data.version}`);
    } catch (err) { showExtensionUploadStatus(`${file.name}: ${err.message}`, true); }
  }
  if (extensionUploadInput) extensionUploadInput.value = "";
  await renderExtensions();
}
$("#extensionChooseFiles")?.addEventListener("click", () => extensionUploadInput?.click());
extensionUploadInput?.addEventListener("change", () => uploadExtensionFiles(extensionUploadInput.files));
if (extensionDropZone) {
  extensionDropZone.addEventListener("click", e => { if (e.target.closest("button")) return; extensionUploadInput?.click(); });
  extensionDropZone.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); extensionUploadInput?.click(); } });
  ["dragenter", "dragover"].forEach(type => extensionDropZone.addEventListener(type, e => { e.preventDefault(); extensionDropZone.classList.add("drag-active"); }));
  ["dragleave", "dragend"].forEach(type => extensionDropZone.addEventListener(type, () => extensionDropZone.classList.remove("drag-active")));
  extensionDropZone.addEventListener("drop", e => { e.preventDefault(); extensionDropZone.classList.remove("drag-active"); uploadExtensionFiles(e.dataTransfer?.files); });
}


const REFRESH_KEY = "serverservice_refresh_interval_v2";
function getRefreshInterval() { let v = 5; try { v = parseInt(localStorage.getItem(REFRESH_KEY) || "5", 10); } catch (e) {} if (isNaN(v) || v < 3 || v > 30) v = 5; return v; }
function setRefreshInterval(v) {
  v = Math.max(3, Math.min(30, parseInt(v, 10) || 5));
  try { localStorage.setItem(REFRESH_KEY, String(v)); } catch (e) {}
  const range = $("#refreshIntervalRange"), num = $("#refreshIntervalNumber");
  if (range) range.value = v;
  if (num) num.value = v;
  const warn = $("#refreshWarningRow");
  if (warn) warn.style.display = (v < 3) ? "" : "none";
  if (refreshTimer) clearInterval(refreshTimer);
  refreshTimer = setInterval(() => { if (!document.hidden) refreshMetrics(true); }, v * 1000);
}
const rangeEl = $("#refreshIntervalRange"), numEl = $("#refreshIntervalNumber");
if (rangeEl) rangeEl.addEventListener("input", e => setRefreshInterval(e.target.value));
if (numEl) numEl.addEventListener("change", e => setRefreshInterval(e.target.value));

function renderNetworkChart(rate) {
  if (!rate) return;
  if (rate.downloadMbps == null && rate.uploadMbps == null) return;
  networkHistory.push({ down: Number(rate.downloadMbps) || 0, up: Number(rate.uploadMbps) || 0 });
  if (networkHistory.length > 60) networkHistory.shift();
  const w = 620, h = 128, bottom = 138, max = Math.max(20, ...networkHistory.flatMap(v => [v.down, v.up]));
  const points = key => networkHistory.map((v, i) => `${i * w / Math.max(1, networkHistory.length - 1)},${bottom - (Math.min(max, v[key]) / max) * h}`).join(" ");
  const down = points("down"), up = points("up");
  const lineD = (p) => p.split(" ").map((v, i) => `${i ? "L" : "M"}${v}`).join(" ");
  const dLine = $("#networkDownloadLine"), uLine = $("#networkUploadLine"), area = $("#networkDownloadArea");
  if (dLine) dLine.setAttribute("d", lineD(down)); if (uLine) uLine.setAttribute("d", lineD(up));
  if (area) area.setAttribute("d", `M${down.replaceAll(" ", " L")} L620 150 L0 150 Z`);
  const note = $("#networkChartNote"); if (note) note.textContent = `실측값 · 축 최대 ${max.toFixed(1)} Mbps · 최근 ${networkHistory.length}개 표본`;
  const axis = $$(".chart-y-labels span"); if (axis.length === 5) [max, max * .75, max * .5, max * .25, 0].forEach((v, i) => axis[i].textContent = `${v.toFixed(v < 10 ? 1 : 0)} Mbps`);
}

function applySystemData(data) {
  if (!data) return;
  if (data.cpu) {
    const rawLoad = (typeof data.cpu === "object") ? data.cpu.load : data.cpu;
    const cpuLoad = rawLoad !== null && rawLoad !== undefined && Number.isFinite(Number(rawLoad)) ? Math.max(0, Math.min(100, Number(rawLoad))) : null;
    if (cpuLoad !== null) {
      $("#cpuValue").innerHTML = `${cpuLoad.toFixed(1)}<span>%</span>`; $("#cpuMeter").style.width = `${cpuLoad.toFixed(1)}%`; $("#cpuGauge").textContent = `${cpuLoad.toFixed(1)}%`;
      const cg = $(".gauge-item[data-detail='cpu'] .gauge"); if (cg) cg.style.setProperty("--percent", cpuLoad);
      const label = cpuLoad < 25 ? "낮은 부하" : cpuLoad < 80 ? "보통 부하" : "높은 부하";
      $("#cpuFoot").textContent = label; const caption = $(".gauge-item[data-detail='cpu'] .gauge-caption"); if (caption) caption.textContent = label;
    } else {
      $("#cpuValue").innerHTML = `—<span>%</span>`; $("#cpuGauge").textContent = "—"; $("#cpuFoot").textContent = "사용률 조회 불가";
    }
    detailData.cpu.html = () => `<div class="detail-row"><span>프로세서</span><strong>${escapeHtml(data.cpu.name || "정보 없음")}</strong></div><div class="detail-row"><span>제조사</span><strong>${escapeHtml(data.cpu.manufacturer || "-")}</strong></div><div class="detail-row"><span>코어 / 논리 프로세서</span><strong>${data.cpu.cores ?? "—"} / ${data.cpu.logicalProcessors ?? "—"}</strong></div><div class="detail-row"><span>최대 클럭</span><strong>${data.cpu.maxClockMHz ? `${(data.cpu.maxClockMHz/1000).toFixed(2)} GHz` : "조회 불가"}</strong></div><div class="detail-row"><span>사용률</span><strong>${cpuLoad === null ? "조회 불가" : `${cpuLoad.toFixed(1)}%`}</strong></div><div class="detail-row"><span>측정 방식</span><strong>${escapeHtml(data.cpu.loadSource || "Windows 성능 카운터")}</strong></div><div class="detail-row"><span>CPU 온도</span><strong>${data.cpu.temp == null ? "미지원 / 센서 미연결" : `${Number(data.cpu.temp).toFixed(1)} °C`}</strong></div><div class="detail-row"><span>온도 측정 출처</span><strong>${escapeHtml(data.cpu.tempSource || "미지원")}</strong></div><p class="muted">CPU 사용률은 Windows 성능 카운터를 우선 사용합니다. 온도는 프로그램에 내장된 LibreHardwareMonitor 센서 라이브러리에서 읽을 수 있을 때만 실측값을 표시합니다.</p>${cpuLoad === null ? "" : `<div class="bar"><i style="width:${cpuLoad}%"></i></div>`}`;
  }
  if (data.ram) {
    const pct = data.ram.total > 0 ? Math.max(0, Math.min(100, Number((data.ram.percent ?? ((data.ram.used / data.ram.total) * 100)).toFixed(1)))) : 0;
    detailData.memory.html = () => `<div class="detail-row"><span>총 메모리</span><strong>${data.ram.total} GB</strong></div><div class="detail-row"><span>사용 중</span><strong>${data.ram.used} GB (${pct}%)</strong></div><div class="detail-row"><span>사용 가능</span><strong>${data.ram.free} GB</strong></div><div class="detail-row"><span>모듈</span><strong>${(data.ram.modules || []).length}개</strong></div><div class="detail-row"><span>모듈 상세</span><strong>${escapeHtml((data.ram.modules || []).map(m => `${m.capacityGB} GB ${m.manufacturer} ${m.partNumber} ${m.speedMHz ? m.speedMHz + " MHz" : ""}`).join(" / ") || "조회 불가")}</strong></div><div class="bar"><i style="width:${pct}%;background:var(--green)"></i></div>`;
    $("#ramValue").innerHTML = `${pct.toFixed(1)}<span>%</span>`;
    $("#ramMeter").style.width = `${pct}%`;
    const rg = $(".gauge-item[data-detail='memory'] .gauge");
    if (rg) rg.style.setProperty("--percent", pct);
    const memGauge = $("#memoryGaugeValue"); if (memGauge) memGauge.textContent = `${pct.toFixed(1)}%`;
    const ramStatus = $("#ramStatus"); if (ramStatus) ramStatus.textContent = pct > 90 ? "사용량 높음" : "사용 가능";
    const foot = $("#ramValue").parentElement.querySelector(".metric-foot span.muted");
    if (foot) foot.textContent = `${data.ram.total} GB 중 ${data.ram.used} GB`;
    const memCaption = $("#memoryGaugeCaption"); if (memCaption) memCaption.textContent = `${data.ram.used} / ${data.ram.total} GB`;
  }
  const summaryRows = $$(".system-info .info-row");
  summaryRows.forEach(row => { const label = row.querySelector("span")?.textContent; const value = row.querySelector("strong"); if (!value) return;
    if (label === "운영체제" && data.os) value.textContent = data.os.name || "정보 없음";
    if (label === "프로세서" && data.cpu) value.textContent = data.cpu.name || "정보 없음";
    if (label === "그래픽 카드" && Array.isArray(data.gpu)) value.textContent = data.gpu.map(g => g.name).filter(Boolean).join(" · ") || "정보 없음";
    if (label === "메모리" && data.ram) value.textContent = `${data.ram.total} GB (${data.ram.modules?.length || 0}개 모듈)`;
    if (label === "저장 장치") value.textContent = (data.storageDevices || []).map(d => `${d.model} (${d.sizeGB ?? "?"} GB)`).join(" · ") || (data.disks || []).map(d => d.name).join(", ") || "정보 없음";
  });
  if (data.computer) {
    const host = $("#hostComputerLabel");
    if (host) { host.textContent = `현재 PC: ${data.computer.name || "이 컴퓨터"}`; host.title = data.computer.source || "ServerService 실행 PC의 정보"; }
  }
  if (data.os || data.cpu || data.ram || Array.isArray(data.gpu)) {
    const panels = $$(".info-card-grid .panel");
    if (panels[0] && data.os) {
      const title = panels[0].querySelector(".big-info"); if (title) title.textContent = data.os.name || "Windows 정보 없음";
      const muted = panels[0].querySelector("p.muted"); if (muted) muted.textContent = data.os.arch || "아키텍처 정보 없음";
      const rows = panels[0].querySelectorAll(".info-row strong"); if (rows[0]) rows[0].textContent = `${data.os.version || "—"} (빌드 ${data.os.build || "—"})`; if (rows[1]) rows[1].textContent = data.os.arch || "—"; if (rows[2]) rows[2].textContent = "Windows에서 별도 조회하지 않음";
    }
    if (panels[1] && data.cpu) {
      const title = panels[1].querySelector(".big-info"); if (title) title.textContent = data.cpu.name || "CPU 정보 없음";
      const muted = panels[1].querySelector("p.muted"); if (muted) muted.textContent = `${data.cpu.cores ?? "—"}코어 · ${data.cpu.logicalProcessors ?? "—"} 논리 프로세서`;
      const rows = panels[1].querySelectorAll(".info-row strong"); if (rows[0]) rows[0].textContent = data.cpu.load == null ? "조회 불가" : `${Number(data.cpu.load).toFixed(1)}%`; if (rows[1]) rows[1].textContent = data.cpu.temp == null ? "미지원 / 센서 미연결" : `${Number(data.cpu.temp).toFixed(1)} °C`; if (rows[2]) rows[2].textContent = data.cpu.maxClockMHz ? `${(data.cpu.maxClockMHz/1000).toFixed(2)} GHz` : "조회 불가";
    }
    if (panels[2] && data.ram) {
      const title = panels[2].querySelector(".big-info"); if (title) title.textContent = `${data.ram.total} GB RAM`;
      const muted = panels[2].querySelector("p.muted"); if (muted) muted.textContent = (data.ram.modules || []).map(m => [m.manufacturer, m.partNumber, m.speedMHz ? `${m.speedMHz} MHz` : ""].filter(Boolean).join(" · ")).filter(Boolean).join(" / ") || "메모리 모듈 상세 정보 없음";
      const rows = panels[2].querySelectorAll(".info-row strong"); if (rows[0]) rows[0].textContent = `${data.ram.used} GB`; if (rows[1]) rows[1].textContent = `${data.ram.free} GB`; if (rows[2]) rows[2].textContent = `${(data.ram.modules || []).length}개 모듈`;
    }
    if (panels[3]) {
      const rows = panels[3].querySelectorAll(".info-row strong");
      if (rows[0]) rows[0].textContent = (data.gpu || []).map(g => g.name).join(" · ") || "GPU 정보 없음";
      if (rows[1]) rows[1].textContent = (data.gpu || []).map(g => g.driver || "드라이버 정보 없음").join(" · ") || "조회 불가";
      if (rows[2]) rows[2].textContent = (data.gpu || []).map(g => g.resolution || "해상도 정보 없음").join(" · ") || "조회 불가";
      if (rows[3]) rows[3].textContent = (data.storageDevices || []).map(d => `${d.model} (${d.sizeGB ?? "?"} GB)`).join(" · ") || "물리 디스크 정보 없음";
      if (rows[4]) rows[4].textContent = data.disks?.length ? data.disks.map(d => `${d.name} ${d.percent}%`).join(" · ") : "볼륨 정보 없음";
    }
  }
  if (data.disks && data.disks.length) {
    const d0 = data.disks.find(d => String(d.name).toUpperCase() === "C:") || data.disks[0];
    if (detailData.disk) detailData.disk.html = () => `<div class="detail-row"><span>볼륨</span><strong>${escapeHtml(d0.name)} ${escapeHtml(d0.volumeName || "")}</strong></div><div class="detail-row"><span>파일 시스템</span><strong>${escapeHtml(d0.fileSystem || "-")}</strong></div><div class="detail-row"><span>사용 공간</span><strong>${Number(d0.used).toFixed(2)} GB (${Number(d0.percent).toFixed(1)}%)</strong></div><div class="detail-row"><span>여유 공간</span><strong>${Number(d0.free ?? (d0.total-d0.used)).toFixed(2)} GB</strong></div><div class="detail-row"><span>물리 디스크</span><strong>${escapeHtml((data.storageDevices || []).map(d => `${d.model} (${d.sizeGB ?? "?"} GB)`).join(", ") || "정보 없음")}</strong></div><div class="detail-row"><span>실시간 디스크 활성 시간</span><strong>${data.diskActivity?.available ? data.diskActivity.devices.map(d => `${escapeHtml(d.name)}: ${d.activePercent == null ? "조회 불가" : Number(d.activePercent).toFixed(1)+"%"}`).join(" / ") : "미지원"}</strong></div><div class="detail-row"><span>읽기 / 쓰기 속도</span><strong>${data.diskActivity?.available ? data.diskActivity.devices.map(d => `${escapeHtml(d.name)}: R ${d.readMBps ?? "—"} / W ${d.writeMBps ?? "—"} MB/s`).join(" / ") : "미지원"}</strong></div><div class="detail-row"><span>디스크 응답 시간</span><strong>${data.diskActivity?.available ? data.diskActivity.devices.map(d => `${escapeHtml(d.name)}: R ${d.readLatencyMs ?? "—"} / W ${d.writeLatencyMs ?? "—"} ms`).join(" / ") : "미지원"}</strong></div><div class="bar"><i style="width:${d0.percent}%;background:var(--orange)"></i></div>`;
    const list = $(".storage-list");
    if (list) {
      list.innerHTML = data.disks.map(d => `<div class="storage-row"><div class="storage-meta"><strong>${escapeHtml(d.name)}</strong><span>${Number(d.used).toFixed(2)} GB / ${Number(d.total).toFixed(2)} GB · ${Number(d.percent).toFixed(1)}%</span></div><div class="meter"><i style="width:${d.percent}%"></i></div></div>`).join("");
    }
    if (d0) {
      $("#diskValue").innerHTML = `${Number(d0.percent).toFixed(1)}<span>%</span>`;
      $("#diskMeter").style.width = `${Number(d0.percent).toFixed(1)}%`;
      const diskGauge = $("#diskGaugeValue"); if (diskGauge) diskGauge.textContent = `${Number(d0.percent).toFixed(1)}%`;
      const diskGaugeEl = $(".gauge-item[data-detail='disk'] .gauge"); if (diskGaugeEl) diskGaugeEl.style.setProperty("--percent", d0.percent);
      const diskStatus = $("#diskStatus"); if (diskStatus) diskStatus.textContent = d0.percent > 90 ? "공간 부족" : "여유 공간 있음";
      $("#diskFoot").textContent = `${Number(d0.used).toFixed(2)} GB / ${Number(d0.total).toFixed(2)} GB`;
    }
  }
  if (Array.isArray(data.processes)) {
    const tbody = $("#runningTab .wide-table");
    if (tbody) {
      const head = tbody.querySelector(".table-head");
      tbody.innerHTML = "";
      if (head) tbody.appendChild(head);
      data.processes.forEach(p => {
        const row = document.createElement("div");
        row.className = "process-row searchable";
        row.innerHTML = `<span class="app-name"></span><span>${p.pid}</span><span>${p.cpu === null || p.cpu === undefined ? "표본 수집 중" : p.cpu + "%"}</span><span>${p.mem} MB</span><span class="state-normal">실행 중</span>`;
        row.querySelector(".app-name").textContent = p.name;
        tbody.appendChild(row);
      });
    }
  }
  if (Array.isArray(data.processes)) {
    const dash = $("#dashboardProcessList");
    if (dash) {
      const head = dash.querySelector(".table-head");
      dash.innerHTML = "";
      if (head) dash.appendChild(head);
      data.processes.slice(0, 5).forEach(p => {
        const row = document.createElement("div"); row.className = "process-row";
        const name = document.createElement("span"); name.className = "app-name"; name.textContent = p.name;
        const pid = document.createElement("span"); pid.textContent = String(p.pid);
        const mem = document.createElement("span"); mem.textContent = `${p.mem} MB`;
        const state = document.createElement("span"); state.textContent = "실행 중";
        row.append(name, pid, mem, state); dash.appendChild(row);
      });
    }
  }
  if (Array.isArray(data.gpu)) {
    const stats = data.gpuStats || {};
    const gpuLoad = stats.utilization !== null && stats.utilization !== undefined && Number.isFinite(Number(stats.utilization)) ? Math.max(0, Math.min(100, Number(stats.utilization))) : null;
    const gauge = $("#gpuGaugeValue"); if (gauge) gauge.textContent = gpuLoad === null ? "—" : `${gpuLoad.toFixed(1)}%`;
    const gaugeEl = $(".gauge-item[data-detail='gpu'] .gauge"); if (gaugeEl && gpuLoad !== null) gaugeEl.style.setProperty("--percent", gpuLoad);
    const gpuItem = $(".gauge-item[data-detail='gpu'] .gauge-caption"); if (gpuItem) gpuItem.textContent = gpuLoad === null ? "사용률 조회 불가" : (stats.utilization3D == null ? "최대 엔진 사용률" : `3D ${Number(stats.utilization3D).toFixed(1)}% · 최대 엔진`);
    const gpuNames = data.gpu.map(g => g.name).filter(Boolean).join(", ") || "정보 없음";
    const gpuDrivers = data.gpu.map(g => g.driver || "-").join(", ");
    const gpuResolutions = data.gpu.map(g => g.resolution || "-").join(", ");
    const reportedRam = data.gpu.map(g => g.adapterRamGBReported == null ? null : `${g.adapterRamGBReported} GB (드라이버 보고값)`).filter(Boolean).join(" / ") || "조회 불가";
    const dedicatedUsed = stats.dedicatedUsedGB == null ? "조회 불가" : `${Number(stats.dedicatedUsedGB).toFixed(2)} GB`;
    const dedicatedTotal = stats.dedicatedTotalGB == null ? "별도 총량 조회 불가" : `${Number(stats.dedicatedTotalGB).toFixed(2)} GB`;
    const sharedUsed = stats.sharedUsedGB == null ? "조회 불가" : `${Number(stats.sharedUsedGB).toFixed(2)} GB`;
    detailData.gpu.html = () => `<div class="detail-row"><span>그래픽 카드</span><strong>${escapeHtml(gpuNames)}</strong></div><div class="detail-row"><span>드라이버 버전</span><strong>${escapeHtml(gpuDrivers)}</strong></div><div class="detail-row"><span>비디오 프로세서</span><strong>${escapeHtml(data.gpu.map(g => g.videoProcessor || "-").join(", "))}</strong></div><div class="detail-row"><span>장치 상태</span><strong>${escapeHtml(data.gpu.map(g => g.status || "-").join(", "))}</strong></div><div class="detail-row"><span>장치 식별자</span><strong>${escapeHtml(data.gpu.map(g => g.pnpDeviceId || "미제공").join(" / "))}</strong></div><div class="detail-row"><span>현재 해상도</span><strong>${escapeHtml(gpuResolutions)}</strong></div><div class="detail-row"><span>주사율</span><strong>${escapeHtml(data.gpu.map(g => Number(g.refreshRate) > 0 ? `${g.refreshRate} Hz` : "조회 불가").join(", "))}</strong></div><div class="detail-row"><span>Windows 보고 전용 메모리</span><strong>${escapeHtml(reportedRam)}</strong></div><div class="detail-row"><span>전용 GPU 메모리 사용량</span><strong>${escapeHtml(dedicatedUsed)} / ${escapeHtml(dedicatedTotal)}</strong></div><div class="detail-row"><span>공유 GPU 메모리 사용량</span><strong>${escapeHtml(sharedUsed)}</strong></div><div class="detail-row"><span>GPU 최대 엔진 사용률</span><strong>${gpuLoad === null ? "조회 불가" : `${gpuLoad.toFixed(1)}%`}</strong></div><div class="detail-row"><span>3D 엔진 사용률</span><strong>${stats.utilization3D == null ? "조회 불가" : `${Number(stats.utilization3D).toFixed(1)}%`}</strong></div><div class="detail-row"><span>GPU 온도</span><strong>${stats.temperatureC == null ? "미지원 / 센서 미연결" : `${Number(stats.temperatureC).toFixed(1)} °C`}</strong></div><div class="detail-row"><span>온도 측정 출처</span><strong>${escapeHtml(stats.temperatureSource || "미지원")}</strong></div><div class="detail-row"><span>측정 엔진 수</span><strong>${stats.engineCount ?? 0}</strong></div>${gpuLoad === null ? "" : `<div class="bar"><i style="width:${gpuLoad}%;background:var(--purple)"></i></div>`}<p class="muted">${escapeHtml(stats.note || "GPU 성능 카운터 제공 여부는 Windows 및 그래픽 드라이버에 따라 다릅니다.")} 전용 메모리의 드라이버 보고값은 일부 GPU에서 부정확하거나 제한될 수 있습니다. GPU 온도는 LibreHardwareMonitor 센서가 제공될 때만 실측값을 표시하며, 미연결 시 추정하지 않습니다.</p>`;
  }
  if (data.networkRate) {
    renderNetworkChart(data.networkRate);
    const down = data.networkRate.downloadMbps == null ? "—" : data.networkRate.downloadMbps.toFixed(2);
    const up = data.networkRate.uploadMbps == null ? "—" : data.networkRate.uploadMbps.toFixed(2);
    ["#downloadRate", "#downloadRatePage"].forEach(id => { const el = $(id); if (el) el.textContent = down; });
    ["#uploadRate", "#uploadRatePage"].forEach(id => { const el = $(id); if (el) el.textContent = up; });
    const note = $("#networkRateNote"); if (note) note.textContent = data.networkRate.downloadMbps == null ? "첫 측정 중…" : "Windows 어댑터 누적 바이트 기반 측정";
  }
  if (data.network) {
    const n = data.network;
    const netStatus = $("#networkConnectionStatus"); if (netStatus) netStatus.textContent = n.ip && n.ip !== "-" ? "연결됨" : "연결 없음";
    const infoRows = $$("#page-network .info-row");
    infoRows.forEach(row => {
      const label = row.querySelector("span");
      const val = row.querySelector("strong");
      if (!label || !val) return;
      if (label.textContent === "어댑터") val.textContent = n.adapter || val.textContent;
      if (label.textContent === "IPv4 주소") val.textContent = n.ip || val.textContent;
      if (label.textContent === "서브넷 마스크") val.textContent = n.mask || val.textContent;
      if (label.textContent === "기본 게이트웨이") val.textContent = n.gateway || val.textContent;
      if (label.textContent === "DNS") val.textContent = n.dns || val.textContent;
    });
  }
  if (Array.isArray(data.blockedPrograms)) {
    const count = data.blockedPrograms.length;
    $$(".security-count").forEach(el => el.textContent = String(count));
    const blockedTabCount = $("#blockedTabCount"); if (blockedTabCount) blockedTabCount.textContent = String(count);
    $$(".security-state").forEach(el => el.textContent = count ? "확인 필요" : "기록 없음");
    const summaryText = $(".security-panel .muted");
    if (summaryText) summaryText.textContent = count ? "보안 기록에서 확인된 항목" : "현재 연결된 보안 기록에 차단 항목이 없습니다.";
    const blockedPanel = $("#blockedTab");
    if (blockedPanel) {
      blockedPanel.innerHTML = `<div class="panel-heading"><div><h2>차단된 프로그램</h2><p class="muted">Windows 보안 기록 기반</p></div></div>`;
      if (!count) {
        blockedPanel.insertAdjacentHTML("beforeend", `<div class="empty-state"><span>⬡</span><strong>차단된 프로그램 기록이 없습니다.</strong><p>연결된 보안 기록에서 확인된 항목이 없습니다.</p></div>`);
      } else {
        data.blockedPrograms.forEach(item => {
          const row = document.createElement("div");
          row.className = "process-row";
          const name = document.createElement("span"); name.className = "app-name"; name.textContent = item.name || "알 수 없는 프로그램";
          const reason = document.createElement("span"); reason.textContent = item.reason || "보안 이벤트";
          const when = document.createElement("span"); when.textContent = item.time || "시간 정보 없음";
          row.append(name, reason, when); blockedPanel.appendChild(row);
        });
      }
    }
  }
  if (Array.isArray(data.installedPrograms)) {
    const panel = $("#installedTab");
    if (panel) {
      panel.innerHTML = `<div class="panel-heading"><div><h2>설치된 프로그램</h2><p class="muted">Windows 등록 프로그램 목록</p></div></div>`;
      if (!data.installedPrograms.length) {
        panel.insertAdjacentHTML("beforeend", `<div class="empty-state"><span>▤</span><strong>등록된 프로그램을 찾지 못했습니다.</strong></div>`);
      } else {
        const table = document.createElement("div"); table.className = "wide-table";
        const head = document.createElement("div"); head.className = "table-head";
        ["프로그램", "버전", "게시자"].forEach(label => { const span = document.createElement("span"); span.textContent = label; head.appendChild(span); });
        table.appendChild(head);
        data.installedPrograms.forEach(item => {
          const row = document.createElement("div"); row.className = "process-row searchable";
          [item.name, item.version || "—", item.publisher || "—"].forEach(value => { const span = document.createElement("span"); span.textContent = value; row.appendChild(span); });
          table.appendChild(row);
        });
        panel.appendChild(table);
      }
    }
  }
  if (Array.isArray(data.startup)) {
    const table = $("#startupTab .startup-table");
    if (table) {
      const head = table.querySelector(".table-head"); table.replaceChildren(); if (head) table.appendChild(head);
      if (!data.startup.length) { const empty = document.createElement("div"); empty.className = "empty-state"; empty.textContent = "Windows에서 등록된 시작 프로그램을 찾지 못했습니다."; table.appendChild(empty); }
      data.startup.forEach(item => {
        const row = document.createElement("div"); row.className = "process-row startup-row"; row.dataset.startup = item.name || "";
        const name = document.createElement("span"); name.className = "app-name"; name.textContent = item.name || "이름 없음";
        const publisher = document.createElement("span"); publisher.textContent = item.publisher || "사용자/게시자 정보 없음";
        const command = document.createElement("span"); command.className = "muted"; command.title = item.command || ""; command.textContent = (item.command || item.location || "명령 정보 없음").slice(0, 90);
        const state = document.createElement("span"); state.className = "state-normal"; state.textContent = "등록됨";
        const action = document.createElement("button"); action.className = "button secondary"; action.type = "button"; action.textContent = "Windows에서 관리"; action.addEventListener("click", () => runAdminAction("startup-settings"));
        row.append(name, publisher, command, state, action); table.appendChild(row);
      });
    }
  }
}

let systemRequest = null;
async function loadSystemData() {
  if (systemRequest) return systemRequest;
  systemRequest = (async () => {
    try {
      const res = await fetch("/api/system", { cache: "no-store" });
      let data = null;
      try { data = await res.json(); } catch (_) { throw new Error(`시스템 API가 JSON이 아닌 응답을 반환했습니다 (HTTP ${res.status}).`); }
      if (!res.ok) throw new Error(data?.detail || data?.error || `시스템 API 오류 (HTTP ${res.status}).`);
      if (!data || typeof data !== "object" || (!data.os && !data.cpu && !data.ram)) {
        throw new Error("시스템 API 응답에 OS/CPU/RAM 데이터가 없습니다.");
      }
      try { applySystemData(data); }
      catch (renderError) {
        console.error("ServerService UI render error:", renderError);
        throw new Error(`정보는 수신했지만 화면 표시 중 오류가 발생했습니다: ${renderError?.message || renderError}`);
      }
      const hostLabel = data.computer?.name ? `실행 PC ${data.computer.name}` : "실제 시스템 정보";
      $("#systemStatus").textContent = `${hostLabel}에서 데이터를 수집 중입니다.`;
    } catch (systemError) {
      console.error("ServerService system data error:", systemError);
      // Distinguish a dead server from a system-information collection failure.
      try {
        const health = await fetch("/api/health", { cache: "no-store" });
        if (health.ok) {
          const info = await health.json();
          $("#systemStatus").textContent = `로컬 서버 연결됨 (v${info.version}). ${systemError?.message || "시스템 정보 수집 실패"} — server.log 확인`;
        } else {
          $("#systemStatus").textContent = `서버 응답 오류 (${health.status}). server.log를 확인하세요.`;
        }
      } catch (_) {
        $("#systemStatus").textContent = "로컬 서버 연결 실패. start.bat 실행 여부와 startup-error.log / server.log를 확인하세요.";
      }
    }
  })().finally(() => { systemRequest = null; });
  return systemRequest;
}

const APP_VERSION = "1.7.4";
async function checkUpdate() {
  const bar = $("#updateBar");
  if (!bar) return;
  bar.classList.add("hidden");
  try {
    const res = await fetch("/api/update", { cache: "no-store" });
    if (!res.ok) return;
    const data = await res.json();
    if (data.available === true && data.version && compareVersions(data.version, APP_VERSION) > 0 && data.fileUrl) {
      const notes = Array.isArray(data.releaseNotes) ? data.releaseNotes.filter(Boolean).join(" · ") : "";
      const sizeText = Number.isFinite(Number(data.size)) ? ` · ${(Number(data.size) / 1048576).toFixed(1)} MB` : "";
      $("#updateMessage").textContent = `새 업데이트 v${data.version}${sizeText}${notes ? ` — ${notes}` : ""}`;
      bar.classList.remove("hidden");
      const btn = $("#updateButton");
      btn.onclick = () => { window.location.href = data.fileUrl; };
    }
  } catch (e) { /* 업데이트 파일이 서버에 없으면 알림을 표시하지 않습니다. */ }
}

function compareVersions(a, b) {
  const pa = a.split(".").map(n => parseInt(n, 10) || 0);
  const pb = b.split(".").map(n => parseInt(n, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const x = pa[i] || 0, y = pb[i] || 0;
    if (x > y) return 1;
    if (x < y) return -1;
  }
  return 0;
}

const developerBackdrop = $("#developerBackdrop");
let developerToken = "";
function closeDeveloper() {
  developerBackdrop.classList.add("hidden");
  developerBackdrop.setAttribute("aria-hidden", "true");
}
$("#developerEntry").addEventListener("click", () => {
  $("#developerError").classList.add("hidden");
  $("#developerLoginForm").classList.remove("hidden");
  $("#developerUploadArea").classList.add("hidden");
  developerBackdrop.classList.remove("hidden");
  developerBackdrop.setAttribute("aria-hidden", "false");
  $("#developerPassword").focus();
});
$("#developerClose").addEventListener("click", closeDeveloper);
developerBackdrop.addEventListener("click", e => { if (e.target === developerBackdrop) closeDeveloper(); });
$("#developerLoginForm").addEventListener("submit", async e => {
  e.preventDefault();
  const err = $("#developerError"); err.classList.add("hidden");
  try {
    const res = await fetch("/api/admin/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ password: $("#developerPassword").value }) });
    const data = await res.json();
    if (!res.ok || !data.token) throw new Error("login");
    developerToken = data.token;
    $("#developerLoginForm").classList.add("hidden");
    $("#developerUploadArea").classList.remove("hidden");
    $("#developerPassword").value = "";
    await refreshAdminStatus();
  } catch (_) { err.classList.remove("hidden"); }
});
$("#developerLogout").addEventListener("click", () => { developerToken = ""; $("#developerUploadArea").classList.add("hidden"); $("#developerLoginForm").classList.remove("hidden"); $("#adminIdentityStatus").textContent = "로그아웃됨"; });
$("#adminPasswordForm")?.addEventListener("submit", async e => {
  e.preventDefault(); const status = $("#adminPasswordStatus");
  const password = $("#adminNewPassword").value; const confirmPassword = $("#adminNewPasswordConfirm").value;
  if (password.length < 8 || password.length > 128) { status.textContent = "새 비밀번호는 8~128자여야 합니다."; return; }
  if (password !== confirmPassword) { status.textContent = "비밀번호가 일치하지 않습니다."; return; }
  if (!confirm("관리자 비밀번호를 변경할까요? 변경 후 새 비밀번호로 다시 로그인해야 합니다.")) return;
  try {
    const res = await fetch("/api/admin/password", { method: "POST", headers: { "Content-Type": "application/json", "X-Admin-Token": developerToken }, body: JSON.stringify({ password }) });
    const data = await res.json(); if (!res.ok) throw new Error(data.error || "비밀번호 변경 실패");
    status.textContent = data.message || "변경 완료"; developerToken = ""; $("#adminNewPassword").value = ""; $("#adminNewPasswordConfirm").value = "";
    $("#developerUploadArea").classList.add("hidden"); $("#developerLoginForm").classList.remove("hidden"); $("#adminIdentityStatus").textContent = "비밀번호 변경 완료 · 다시 로그인하세요.";
  } catch (err) { status.textContent = `변경 실패: ${err.message}`; }
});
async function refreshAdminStatus() {
  const el = $("#adminIdentityStatus");
  try { const res = await fetch("/api/admin/status", { headers: { "X-Admin-Token": developerToken }, cache: "no-store" }); const data = await res.json(); if (!res.ok) throw new Error(data.error || "권한 상태를 확인할 수 없습니다."); el.textContent = `${data.user} · ${data.elevated ? "관리자 권한으로 실행 중" : "일반 권한으로 실행 중"} · 세션 만료 ${new Date(data.expiresAt).toLocaleTimeString("ko-KR")}`; }
  catch (_) { el.textContent = "권한 상태를 확인할 수 없습니다. 다시 로그인하세요."; }
}
async function runAdminAction(action) {
  const status = $("#adminCommandStatus");
  if (action === "refresh") { status.textContent = "시스템 정보를 새로고침합니다…"; await refreshMetrics(false); status.textContent = "시스템 정보 새로고침 완료"; return; }
  
  status.textContent = "Windows 관리 도구를 여는 중…";
  try { const res = await fetch("/api/admin/action", { method: "POST", headers: { "Content-Type": "application/json", "X-Admin-Token": developerToken }, body: JSON.stringify({ action }) }); const data = await res.json(); if (!res.ok) throw new Error(data.error || "작업 실패"); status.textContent = data.message || "작업 완료"; }
  catch (err) { status.textContent = `작업 실패: ${err.message}`; }
}
$$("[data-admin-action]").forEach(button => button.addEventListener("click", () => runAdminAction(button.dataset.adminAction)));
$("#adminChatGPT")?.addEventListener("click", () => window.open("https://chatgpt.com/", "_blank", "noopener,noreferrer"));
$("#updateUploadForm").addEventListener("submit", async e => {
  e.preventDefault();
  const file = $("#updateFile").files[0];
  const version = $("#updateVersion").value.trim();
  const status = $("#uploadStatus");
  if (!file || !/^[0-9]+(\.[0-9]+){1,3}$/.test(version)) { status.textContent = "버전과 업데이트 파일을 확인하세요."; return; }
  if (file.size > 500 * 1024 * 1024) { status.textContent = "파일은 500MB 이하만 업로드할 수 있습니다."; return; }
  if (!confirm(`v${version} 업데이트 파일 '${file.name}'을 업로드할까요?`)) return;
  status.textContent = "업로드 중…";
  try {
    const res = await fetch(`/api/admin/upload?version=${encodeURIComponent(version)}&filename=${encodeURIComponent(file.name)}&notes=${encodeURIComponent(( $("#updateReleaseNotes")?.value || "").trim())}`, { method: "POST", headers: { "X-Admin-Token": developerToken, "Content-Type": "application/octet-stream" }, body: file });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "업로드 실패");
    status.textContent = "업로드가 완료되었습니다. 업데이트 알림에 반영됩니다.";
    await checkUpdate();
  } catch (err) { status.textContent = `업로드 실패: ${err.message}`; }
});

$("#extensionUploadForm")?.addEventListener("submit", async e => {
  e.preventDefault();
  const file = $("#extensionPackageFile")?.files?.[0];
  const status = $("#extensionUploadStatus");
  if (!file || !file.name.toLowerCase().endsWith(".zip")) { status.textContent = "Manifest V3 확장프로그램 .zip 파일을 선택하세요."; return; }
  if (file.size > 100 * 1024 * 1024) { status.textContent = "확장프로그램 패키지는 100MB 이하만 업로드할 수 있습니다."; return; }
  if (!confirm(`확장프로그램 '${file.name}'을 등록할까요? 업로드된 파일은 실행하지 않고 구조만 검사합니다.`)) return;
  status.textContent = "패키지 업로드 및 검사 중…";
  try {
    const res = await fetch(`/api/admin/extensions/upload?filename=${encodeURIComponent(file.name)}`, { method: "POST", headers: { "X-Admin-Token": developerToken, "Content-Type": "application/octet-stream" }, body: file });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "업로드 실패");
    status.textContent = `등록 완료: ${data.name} v${data.version}. 카탈로그에 반영되었습니다.`;
    $("#extensionPackageFile").value = "";
    await renderExtensions();
    $("#systemStatus").textContent = `확장프로그램 '${data.name}'이(가) 등록되었습니다.`;
  } catch (err) { status.textContent = `업로드 실패: ${err.message}`; }
});

// Device inventory and safe, user-confirmed tuning actions.
let deviceInventory = [];
const vendorTools = [
  { keys: ["logitech", "logicool"], name: "Logitech G HUB", url: "https://www.logitechg.com/innovation/g-hub.html" },
  { keys: ["razer"], name: "Razer Synapse", url: "https://www.razer.com/synapse-4" },
  { keys: ["corsair"], name: "Corsair iCUE", url: "https://www.corsair.com/icue" },
  { keys: ["hyperx"], name: "HyperX NGENUITY", url: "https://hyperx.com/pages/ngenuity" },
  { keys: ["asus", "republic of gamers", "rog"], name: "ASUS Armoury Crate", url: "https://www.asus.com/supportonly/armoury%20crate/helpdesk_download/" },
  { keys: ["msi"], name: "MSI Center", url: "https://www.msi.com/Landing/MSI-Center" },
  { keys: ["steelseries"], name: "SteelSeries GG", url: "https://steelseries.com/gg" },
  { keys: ["glorious"], name: "Glorious CORE", url: "https://www.gloriousgaming.com/pages/glorious-core" },
  { keys: ["redragon"], name: "Redragon software", url: "https://www.redragonzone.com/pages/download" },
  { keys: ["zowie", "benq"], name: "ZOWIE support", url: "https://zowie.benq.com/en/support.html" },
  { keys: ["dell"], name: "Dell Support", url: "https://www.dell.com/support/home/" },
  { keys: ["lenovo"], name: "Lenovo Support", url: "https://support.lenovo.com/" },
  { keys: ["hp", "hewlett-packard"], name: "HP Support", url: "https://support.hp.com/" },
  { keys: ["gigabyte", "aorus"], name: "GIGABYTE support", url: "https://www.gigabyte.com/Support" },
  { keys: ["keychron"], name: "Keychron Launcher", url: "https://launcher.keychron.com/" }
];
function esc(value) { return escapeHtml(String(value ?? "")); }
function deviceText(d) { return [d.name, d.manufacturer].filter(Boolean).join(" · "); }
function matchingVendor(devices) {
  const text = devices.map(d => `${d.name || ""} ${d.manufacturer || ""}`).join(" ").toLowerCase();
  return vendorTools.find(v => v.keys.some(k => text.includes(k))) || null;
}
function renderDeviceInfo(id, devices, emptyText) {
  const el = $(id); if (!el) return;
  if (!devices.length) { el.innerHTML = `<p class="muted">${esc(emptyText)}</p>`; return; }
  el.innerHTML = devices.slice(0, 8).map(d => `<div class="detected-device-row"><strong>${esc(d.name || "이름 없음")}</strong><span>${esc(d.manufacturer || "제조사 미상")} · ${esc(d.status || "상태 미상")}</span>${d.pnpClass || d.pnpDeviceId ? `<small title="${esc(d.pnpDeviceId || "")}" class="device-id-line">분류: ${esc(d.pnpClass || "미상")} · 장치 ID: ${esc(d.pnpDeviceId || "Windows에서 제공하지 않음")}</small>` : ""}</div>`).join("");
}
function renderVendorLink(id, devices, label) {
  const el = $(id); if (!el) return;
  const vendor = matchingVendor(devices);
  el.innerHTML = vendor ? `<p class="muted">감지된 제조사에 맞는 공식 지원 페이지</p><a class="button secondary vendor-link" href="${vendor.url}" target="_blank" rel="noopener noreferrer">${esc(vendor.name)} 다운로드/지원 ↗</a>` : `<p class="muted">${devices.length ? "제조사 전용 소프트웨어를 확실히 식별하지 못했습니다." : "연결 장치가 감지되지 않았습니다."} ${esc(label)}의 공식 지원 페이지를 모델명으로 확인하세요.</p>`;
}
function getDevicesBy(types) { return deviceInventory.filter(d => types.includes(String(d.kind || "").toLowerCase())); }
function renderAllDevices() {
  const el = $("#allDevicesList"); if (!el) return;
  $("#deviceCountLabel").textContent = `${deviceInventory.length}개`;
  if (!deviceInventory.length) { el.innerHTML = '<p class="muted">Windows에서 조회한 장치가 없습니다.</p>'; return; }
  el.innerHTML = deviceInventory.map(d => `<div class="all-device-row"><span class="device-kind">${esc(d.kind || "장치")}</span><div><strong>${esc(d.name || "이름 없음")}</strong><p class="muted">${esc(d.manufacturer || "제조사 미상")} · ${esc(d.status || "상태 미상")}</p><small class="device-id-line">분류: ${esc(d.pnpClass || "미상")} · 장치 ID: ${esc(d.pnpDeviceId || "Windows에서 제공하지 않음")}</small></div></div>`).join("");
}
function currentMonitor() { return deviceInventory.find(d => String(d.kind).toLowerCase() === "monitor") || null; }
function buildMonitorRecommendation() {
  const m = currentMonitor();
  const genre = $("#gameGenre")?.value || "fps";
  const summary = $("#monitorSummary"), box = $("#profileRecommendation");
  if (!summary || !box) return;
  if (!m) { summary.innerHTML = '<strong>모니터를 감지하지 못했습니다.</strong><span>디스플레이 연결 상태를 확인한 뒤 다시 검색하세요.</span>'; box.innerHTML = '<h3>추천 설정</h3><p>실제 모니터 사양이 없으므로 추정값을 적용하지 않습니다.</p>'; return; }
  const resolution = m.resolution || "현재 해상도 미확인";
  const refresh = Number(m.refreshRate) > 0 ? `${m.refreshRate} Hz` : "현재 주사율 미확인";
  summary.innerHTML = `<strong>${esc(m.name || "연결된 모니터")}</strong><span>${esc(m.manufacturer || "제조사 미상")} · ${esc(resolution)} · ${esc(refresh)}</span><span>${esc(m.physicalSize || "패널 크기 정보 없음")} · Windows가 보고한 현재 모드 기준</span>`;
  const profiles = {
    fps: { title: "FPS · 반응 속도 우선", items: ["Windows에서 현재 모니터가 지원하는 가장 높은 주사율을 선택", "NVIDIA 전원 관리 모드는 게임별로 '최고 성능 선호' 검토", "게임 내 V-Sync는 지연 시간 선호에 따라 끄기/가변 주사율 검토", "해상도는 현재 네이티브 해상도를 우선 유지"] },
    rpg: { title: "RPG · 균형", items: ["현재 네이티브 해상도 유지", "지원되는 높은 주사율과 화질 설정의 균형", "게임별 NVIDIA 이미지 품질/전원 설정을 확인"] },
    story_high: { title: "고퀄리티 스토리 · 화질 우선", items: ["모니터의 현재 네이티브 해상도 유지", "게임에서 높은 텍스처/안티앨리어싱을 GPU 여유에 맞게 조정", "HDR은 모니터와 Windows가 지원할 때만 켜기"] },
    story_low: { title: "저사양/저퀄리티 스토리 · 안정성", items: ["모니터 네이티브 해상도를 기본으로 두고 게임 내부 해상도 스케일 조절", "프레임 안정성을 우선하고 그래픽 옵션을 단계적으로 낮추기", "NVIDIA 제어판에서 게임별 설정을 사용하고 전역 설정은 유지"] }
  };
  const p = profiles[genre];
  box.innerHTML = `<h3>${esc(p.title)}</h3><ul>${p.items.map(x => `<li>${esc(x)}</li>`).join("")}</ul><p class="tiny-note">권장사항이며, 드라이버가 실제로 지원하는 모드를 확인하지 못한 값은 자동 적용하지 않습니다.</p>`;
}
async function loadDevices(force = false) {
  const button = $("#deviceScanButton"); if (button) { button.disabled = true; button.textContent = "검색 중…"; }
  try {
    const res = await fetch(`/api/devices${force ? "?refresh=1" : ""}`, { cache: "no-store" });
    const data = await res.json(); if (!res.ok) throw new Error(data.error || "장치 조회 실패");
    deviceInventory = Array.isArray(data.devices) ? data.devices : [];
    const hostDeviceLabel = $("#hostComputerLabel"); if (hostDeviceLabel && data.computerName) hostDeviceLabel.textContent = `현재 PC: ${data.computerName}`;
    const monitors = getDevicesBy(["monitor"]), mice = getDevicesBy(["mouse"]), keyboards = getDevicesBy(["keyboard"]), audio = getDevicesBy(["audio"]);
    renderDeviceInfo("#mouseDeviceInfo", mice, "마우스 장치가 감지되지 않았습니다.");
    renderDeviceInfo("#keyboardDeviceInfo", keyboards, "키보드 장치가 감지되지 않았습니다.");
    renderDeviceInfo("#headsetDeviceInfo", audio, "헤드셋/오디오 장치가 감지되지 않았습니다.");
    renderVendorLink("#mouseSoftwareLink", mice, "마우스");
    renderVendorLink("#keyboardSoftwareLink", keyboards, "키보드");
    renderVendorLink("#headsetSoftwareLink", audio, "헤드셋");
    const state = $("#monitorDetectedState"); if (state) state.textContent = monitors.length ? `${monitors.length}대 감지됨` : "모니터 미감지";
    renderAllDevices(); buildMonitorRecommendation();
    const speed = Number(data.mouseSpeed); if (speed >= 1 && speed <= 20) { $("#mouseSpeed").value = String(speed); $("#mouseSpeedLabel").textContent = `${speed} / 20`; }
    if (typeof data.mouseAcceleration === "boolean") $("#mouseEnhancePrecision").checked = data.mouseAcceleration;
    const keyboardTuning = $("#keyboardTuningInfo");
    if (keyboardTuning) {
      const rate = data.keyboardRepeatRate == null ? "조회 불가" : `${data.keyboardRepeatRate} / 31 (Windows 설정값)`;
      const delayMap = {0:"짧음",1:"보통",2:"김",3:"매우 김"};
      const delay = data.keyboardRepeatDelay == null ? "조회 불가" : `${data.keyboardRepeatDelay} (${delayMap[data.keyboardRepeatDelay] || "Windows 설정값"})`;
      keyboardTuning.innerHTML = `<div class="detail-row"><span>키 반복 속도</span><strong>${esc(rate)}</strong></div><div class="detail-row"><span>키 반복 지연</span><strong>${esc(delay)}</strong></div><p class="tiny-note">키보드 폴링레이트와 실제 스위치 응답 시간은 일반 Windows API에서 정확히 읽을 수 없습니다.</p>`;
    }
    if (!monitors.length) { const summary = $("#monitorSummary"); if (summary) summary.innerHTML = '<strong>모니터 정보 미확인</strong><span>장치 관리자 또는 Windows 디스플레이 설정에서 모델명을 확인하세요.</span>'; }
  } catch (e) {
    const status = $("#monitorApplyStatus"); if (status) status.textContent = `장치 검색 실패: ${e.message}`;
  } finally { if (button) { button.disabled = false; button.textContent = "↻ 장치 다시 검색"; } }
}
$("#deviceScanButton")?.addEventListener("click", () => loadDevices(true));
$("#gameGenre")?.addEventListener("change", buildMonitorRecommendation);
$("#mouseSpeed")?.addEventListener("input", e => { $("#mouseSpeedLabel").textContent = `${e.target.value} / 20`; });
$("#applyMonitorProfile")?.addEventListener("click", async () => {
  const status = $("#monitorApplyStatus");
  if (!currentMonitor()) { status.textContent = "모니터 사양이 확인되지 않아 적용을 중단했습니다. 장치를 다시 검색하세요."; return; }
  const genre = $("#gameGenre").value;
  const labels = { fps: "FPS", rpg: "RPG", story_high: "고퀄리티 스토리", story_low: "저사양 스토리" };
  if (!confirm(`${labels[genre]} 추천 프로필을 저장하고 NVIDIA 제어판을 열까요? NVIDIA 드라이버 옵션은 제어판에서 최종 확인해야 합니다.`)) return;
  status.textContent = "프로필 저장 및 NVIDIA 제어판 열기 요청 중…";
  try {
    const res = await fetch("/api/device-profile/apply", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ genre }) });
    const data = await res.json(); if (!res.ok) throw new Error(data.error || "적용 요청 실패");
    status.textContent = data.message;
  } catch (e) { status.textContent = `적용 실패: ${e.message}`; }
});
$("#openNvidiaPanel")?.addEventListener("click", async () => {
  try { const r = await fetch("/api/device-tools/open", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ tool: "nvidia" }) }); const d = await r.json(); $("#monitorApplyStatus").textContent = d.message || d.error; }
  catch (e) { $("#monitorApplyStatus").textContent = `열기 실패: ${e.message}`; }
});
$("#openDisplaySettings")?.addEventListener("click", () => openDeviceTool("display"));
$("#openAudioSettings")?.addEventListener("click", () => openDeviceTool("audio"));
async function openDeviceTool(tool) {
  try { const r = await fetch("/api/device-tools/open", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ tool }) }); const d = await r.json(); $("#monitorApplyStatus").textContent = d.message || d.error; }
  catch (e) { $("#monitorApplyStatus").textContent = `열기 실패: ${e.message}`; }
}
$("#applyMouseSettings")?.addEventListener("click", async () => {
  const status = $("#mouseApplyStatus");
  if (!confirm("Windows 포인터 속도와 포인터 정확도 향상 설정을 변경할까요? 실제 마우스 하드웨어 DPI는 변경되지 않습니다.")) return;
  try {
    const res = await fetch("/api/device-settings/mouse", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ pointerSpeed: Number($("#mouseSpeed").value), acceleration: $("#mouseEnhancePrecision").checked }) });
    const data = await res.json(); if (!res.ok) throw new Error(data.error || "설정 변경 실패"); status.textContent = data.message;
  } catch (e) { status.textContent = `설정 변경 실패: ${e.message}`; }
});

const MODULE_KEY = "serverservice_builtin_modules_v1";
function getModuleState() {
  const defaults = { audio: true, devices: true };
  try { return { ...defaults, ...JSON.parse(localStorage.getItem(MODULE_KEY) || "{}") }; } catch (_) { return defaults; }
}
function applyModuleState() {
  const state = getModuleState();
  Object.entries(state).forEach(([id, enabled]) => {
    const nav = $(`.nav-item[data-page="${id}"]`), page = $(`#page-${id}`);
    if (nav) nav.classList.toggle("hidden", !enabled);
    if (page) page.dataset.moduleDisabled = enabled ? "false" : "true";
    if (!enabled && page?.classList.contains("active")) showPage("dashboard");
    if (id === "audio" && !enabled) {
      const audioRoot = page?.querySelector("[data-audio-monitor]");
      if (audioRoot?.__audioMonitor?.running) audioRoot.__audioMonitor.stop();
    }
  });
  $$('[data-module-toggle]').forEach(input => { input.checked = state[input.dataset.moduleToggle] !== false; });
}
$$('[data-module-toggle]').forEach(input => input.addEventListener("change", () => {
  const state = getModuleState(); state[input.dataset.moduleToggle] = input.checked;
  try { localStorage.setItem(MODULE_KEY, JSON.stringify(state)); } catch (_) {}
  applyModuleState();
}));
const originalShowPage = showPage;
showPage = function(name) {
  const state = getModuleState();
  if ((name === "audio" || name === "devices") && state[name] === false) name = "dashboard";
  originalShowPage(name);
};

(function init() {
  const theme = localStorage.getItem("serverservice_theme") || "dark";
  setTheme(theme);
  renderExtensions();
  applyModuleState();
  loadDevices();
  setRefreshInterval(getRefreshInterval());
  loadSystemData();
  checkUpdate();
})();