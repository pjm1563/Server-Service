﻿# ServerService v1.7.4 — 패치 노트

## 변경 사항
- 상단 상태바의 ChatGPT 버튼을 제거했습니다.
- 관리자 콘솔에만 “GPT로 가기” 버튼을 배치했습니다. 버튼은 관리자 창을 열어야 접근할 수 있습니다.
- 사이드바 버전 표기 아래에 다음 소유자 문구를 작게 추가했습니다.
  - Developer: jin1563
  - © 2026 jin1563. All rights reserved.
  - Developed by jin1563
- 앱·서버·설치 프로그램의 버전을 1.7.4로 맞췄습니다.

## 검사 범위
- JavaScript 문법, 버전 문자열, 버튼 위치 및 ZIP 무결성을 정적으로 검사했습니다.
- Windows 실기 실행은 이 환경에서 수행하지 않았습니다.

## 이전 변경 기록
# ServerService v1.7.3 — 패치 노트

릴리스 날짜: 2026-10-27  
기준: v1.6.9 시작 창 종료 수정본 (API 미사용 구성)

## 수정 사항
- **라이트 모드 상단바:** 다크 전용 고정 그라데이션을 제거하고 밝은 배경과 얇은 경계선으로 조정했습니다.
- **오디오 모니터 테마:** 파형/스펙트럼 캔버스 배경과 기준선을 CSS 테마 변수에 연결했습니다. 다크 모드와 화이트(라이트) 모드의 대비가 각각 유지됩니다.
- **실시간 테마 전환:** 오디오 모니터가 실행 중이면 다음 프레임부터 색상을 반영하고, 정지 상태이면 테마 변경을 감지해 캔버스를 다시 그립니다.
- **버전 정합성:** 앱, PowerShell 서버, 실행 스크립트 및 설치 프로그램 버전을 1.7.0으로 맞췄습니다.
- **시작 진단 유지:** CMD 창 유지와 `startup-error.log` / `server.log` 안내를 유지했습니다.

## 최적화·검토 과정 5회
1. **최적화 → 검토:** 고정된 어두운 상단바와 오디오 캔버스 색상 코드를 찾아 문제 범위를 정했습니다.
2. **수정:** 상단바를 테마 기반으로 변경하고 라이트 모드 전용 스타일을 추가했습니다.
3. **검토 → 수정:** JavaScript 캔버스에도 다크 전용 색상이 남아 있음을 확인하고 CSS 변수 기반 팔레트로 교체했습니다.
4. **검토 → 수정:** 정지 상태에서는 테마 전환이 캔버스에 반영되지 않을 수 있어 `data-theme` 변경 감지를 추가했습니다.
5. **최종 검토:** 버전 일치, JavaScript 구문, ZIP 무결성, 핵심 CSS/오디오 코드의 잔여 고정 색상 참조를 확인했습니다.

## 검증 범위 및 한계
- JavaScript 구문 검사 및 ZIP 무결성 검사를 수행합니다.
- 소스의 테마 변수 연결과 버전 표기를 정적으로 검토합니다.
- 이 환경에서 Windows UI/PowerShell/마이크 권한을 직접 실행할 수 없으므로 실제 Windows 실기 검증은 아직 완료되지 않았습니다.
- 오디오 분석은 기존처럼 브라우저의 마이크 입력을 로컬에서 분석하며 오디오 저장·전송 기능을 추가하지 않았습니다.


## v1.7.1 — CMD/PowerShell encoding repair
- Re-encoded all PowerShell scripts as UTF-8 with BOM for Windows PowerShell 5.1 compatibility.
- Replaced the batch launcher text with ASCII-only output and simplified flow labels to prevent Korean code-page corruption from producing misleading CMD errors.
- Kept the API-free/local-only architecture and audio/theme features.
- Static checks: JavaScript syntax, version consistency, expected files, and ZIP integrity.
- Not verified: live Windows PowerShell execution and actual audio device permissions.


## v1.7.3 — 시스템 정보 조회 복구 및 진단 강화
- OS/CPU 정보 조회 시 CIM 실패에 대비한 WMI 대체 경로를 추가했습니다.
- `/api/system` 요청의 시작/성공 여부와 응답 크기를 `server.log`에 기록합니다.
- API 오류 응답의 상세 메시지를 화면 상태에 표시하고, 수신 오류와 UI 렌더링 오류를 구분합니다.
- ZIP/JavaScript 정적 검사를 수행했습니다. 실제 Windows 환경 실행 검증은 수행하지 못했습니다.


## v1.7.3 — Local-only system collection reliability
- No external API services are used. The loopback-only local HTTP bridge remains necessary for the browser UI to read Windows system data.
- Disabled synchronous optional LibreHardwareMonitor sensor polling in this build because a driver/sensor update can block the complete system response on some PCs. CPU/GPU temperatures may show unavailable; core OS/CPU/RAM/disk/network inventory remains collected through Windows.
- Added phase timing logs for system collection and explicit `/api/system` failure responses.
