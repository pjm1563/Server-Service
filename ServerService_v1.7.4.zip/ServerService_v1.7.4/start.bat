@echo off
setlocal
cd /d "%~dp0"
title ServerService v1.7.4
where powershell.exe >nul 2>&1
if errorlevel 1 goto no_powershell
echo ServerService v1.7.4 starting...
echo Folder: %~dp0
echo The window will stay open after exit so errors can be read.
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0launch.ps1"
set "SERVER_EXIT=%ERRORLEVEL%"
echo.
if "%SERVER_EXIT%"=="0" goto finished
echo [ERROR] Startup script returned exit code %SERVER_EXIT%.
:finished
echo Check startup-error.log and server.log for details.
pause
exit /b %SERVER_EXIT%
:no_powershell
echo [ERROR] Windows PowerShell was not found.
echo Please verify Windows PowerShell 5.1 is available.
pause
exit /b 1
