﻿$ErrorActionPreference = "Stop"
$logPath = Join-Path $PSScriptRoot "startup-error.log"
function Write-StartupLog {
    param([string]$Message)
    try { ("[{0}] {1}" -f (Get-Date -Format o), $Message) | Add-Content -LiteralPath $logPath -Encoding UTF8 } catch {}
}
try {
    Set-Location -LiteralPath $PSScriptRoot
    Write-StartupLog ("ServerService v1.7.4 launch (PID={0}, User={1})" -f $PID, [Environment]::UserName)
    $serverPath = Join-Path $PSScriptRoot 'server.ps1'
    if (-not (Test-Path -LiteralPath $serverPath -PathType Leaf)) {
        throw "server.ps1 file was not found: $serverPath"
    }
    & $serverPath
    Write-StartupLog 'server.ps1 process returned.'
} catch {
    $details = ($_ | Out-String).Trim()
    Write-StartupLog ("STARTUP ERROR: " + $details)
    Write-Host "`nServerService startup error:" -ForegroundColor Red
    Write-Host $details -ForegroundColor Yellow
    Write-Host "`nLog file: $logPath"
    exit 1
}
