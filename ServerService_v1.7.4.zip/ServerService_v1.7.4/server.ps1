﻿param([int]$Port = 8765)
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:ServerLogPath = Join-Path $root 'server.log'
function Write-ServerLog { param([string]$Message) try { ('[{0}] {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'), $Message) | Add-Content -LiteralPath $script:ServerLogPath -Encoding UTF8 } catch {} }
$script:AppVersion = '1.7.4'
$uploadRoot = Join-Path $root "updates"
$extensionRoot = Join-Path $env:LOCALAPPDATA "ServerService\extensions"
$extensionInboxRoot = Join-Path $root "Uploads"
$extensionDownloadRoot = Join-Path $root "Downloads"
New-Item -ItemType Directory -Path $uploadRoot -Force | Out-Null
New-Item -ItemType Directory -Path $extensionRoot -Force | Out-Null
New-Item -ItemType Directory -Path $extensionInboxRoot -Force | Out-Null
New-Item -ItemType Directory -Path $extensionDownloadRoot -Force | Out-Null
Add-Type -AssemblyName System.IO.Compression.FileSystem
$script:AdminToken = $null
$script:AdminTokenExpires = [datetime]::MinValue
$script:LoginFailures = 0
$script:LoginLockedUntil = [datetime]::MinValue
$script:LastNetSample = $null
$script:LastNetSampleAt = $null
$script:LastProcessSample = @{}
$script:LastProcessSampleAt = $null
$script:CpuRawSample = @{}
$script:CpuSampleAt = $null
$script:StaticInventory = $null
$script:StaticInventoryAt = [datetime]::MinValue
$script:DeviceInventoryCache = $null
$script:DeviceInventoryAt = [datetime]::MinValue
$script:HardwareSensorCache = $null
$script:HardwareSensorCacheAt = [datetime]::MinValue
$script:LhmComputer = $null
$script:LhmInitAttempted = $false
$script:LhmInitError = $null
$script:LhmAssemblyResolver = $null
$script:DiskCounterCache = $null
$script:DiskCounterCacheAt = [datetime]::MinValue
$script:AdminPasswordHash = "8C6976E5B5410415BDE908BD4DEE15DFB167A9C873FC4BB8A81F6F2AB448A918"
$adminConfigDir = Join-Path $env:LOCALAPPDATA "ServerService"
$adminConfigPath = Join-Path $adminConfigDir "admin.json"
try { if (Test-Path -LiteralPath $adminConfigPath) { $savedAdmin = Get-Content -LiteralPath $adminConfigPath -Raw | ConvertFrom-Json; if ([string]$savedAdmin.passwordHash -match '^[A-Fa-f0-9]{64}$') { $script:AdminPasswordHash = [string]$savedAdmin.passwordHash } } } catch {}

function Initialize-EmbeddedHardwareMonitor {
    if ($script:LhmInitAttempted) { return ($null -ne $script:LhmComputer) }
    $script:LhmInitAttempted = $true
    $libRoot = Join-Path $root 'lib\LibreHardwareMonitor'
    $libraryPath = Join-Path $libRoot 'LibreHardwareMonitorLib.dll'
    if (-not (Test-Path -LiteralPath $libraryPath)) { $script:LhmInitError = '내장 센서 라이브러리 파일이 없습니다.'; return $false }
    try {
        # Resolve managed dependencies from the bundled private library directory without installing anything globally.
        $resolverScript = {
            param($sender, $eventArgs)
            try {
                $requested = ([System.Reflection.AssemblyName]::new($eventArgs.Name)).Name + '.dll'
                $candidate = Join-Path $libRoot $requested
                if (Test-Path -LiteralPath $candidate) { return [System.Reflection.Assembly]::LoadFrom($candidate) }
            } catch {}
            return $null
        }.GetNewClosure()
        $script:LhmAssemblyResolver = [System.ResolveEventHandler]$resolverScript
        [AppDomain]::CurrentDomain.add_AssemblyResolve($script:LhmAssemblyResolver)
        [void][System.Reflection.Assembly]::LoadFrom($libraryPath)
        $computerType = [type]::GetType('LibreHardwareMonitor.Hardware.Computer, LibreHardwareMonitorLib', $true)
        $computer = [Activator]::CreateInstance($computerType)
        foreach ($propertyName in @('IsCpuEnabled','IsGpuEnabled','IsMotherboardEnabled','IsStorageEnabled','IsMemoryEnabled')) {
            try { $computerType.GetProperty($propertyName).SetValue($computer, $true, $null) } catch {}
        }
        foreach ($propertyName in @('IsControllerEnabled','IsNetworkEnabled','IsBatteryEnabled','IsPsuEnabled','IsPowerMonitorEnabled')) {
            try { $computerType.GetProperty($propertyName).SetValue($computer, $false, $null) } catch {}
        }
        $computerType.GetMethod('Open').Invoke($computer, @())
        $script:LhmComputer = $computer
        Write-ServerLog '내장 LibreHardwareMonitor 센서 엔진 초기화 성공'
        return $true
    } catch {
        $script:LhmInitError = ($_ | Out-String).Trim()
        Write-ServerLog ('내장 센서 엔진 초기화 실패: ' + $script:LhmInitError)
        $script:LhmComputer = $null
        return $false
    }
}

function Get-HardwareSensorData {
    # Local-only build: do not synchronously query the optional LibreHardwareMonitor driver/sensor layer.
    # Some systems/driver combinations can block hardware.Update(), preventing /api/system from replying.
    return [pscustomobject]@{
        available = $false
        source = 'Windows built-in counters only'
        sensors = @()
        note = '선택적 하드웨어 센서 조회를 비활성화했습니다. OS/CPU/RAM/디스크/네트워크 정보는 Windows 기본 조회로 수집합니다.'
    }
}

function Get-DiskActivityData {
    $result = [ordered]@{ available = $false; source = 'Windows PhysicalDisk performance counters'; devices = @(); note = '실시간 디스크 성능 카운터를 사용할 수 없습니다.' }
    try {
        $rows = @(Get-CimInstance Win32_PerfFormattedData_PerfDisk_PhysicalDisk -ErrorAction Stop | Where-Object { $_.Name -ne '_Total' })
        $items = @($rows | ForEach-Object {
            $active = $null; $read = $null; $write = $null; $readMs = $null; $writeMs = $null
            try { if ($null -ne $_.PercentDiskTime) { $active = [math]::Max([double]0,[math]::Min([double]100,[double]$_.PercentDiskTime)) } } catch {}
            try { if ($null -ne $_.DiskReadBytesPersec) { $read = [math]::Round(([double]$_.DiskReadBytesPersec / 1MB),2) } } catch {}
            try { if ($null -ne $_.DiskWriteBytesPersec) { $write = [math]::Round(([double]$_.DiskWriteBytesPersec / 1MB),2) } } catch {}
            try { if ($null -ne $_.AvgDisksecPerRead) { $readMs = [math]::Round(([double]$_.AvgDisksecPerRead * 1000),2) } } catch {}
            try { if ($null -ne $_.AvgDisksecPerWrite) { $writeMs = [math]::Round(([double]$_.AvgDisksecPerWrite * 1000),2) } } catch {}
            [pscustomobject]@{ name=[string]$_.Name; activePercent=$active; readMBps=$read; writeMBps=$write; readLatencyMs=$readMs; writeLatencyMs=$writeMs }
        })
        if ($items.Count -gt 0) { $result.available = $true; $result.devices = $items; $result.note = 'Windows PhysicalDisk 성능 카운터'; }
    } catch { }
    return [pscustomobject]$result
}

function Get-SystemData {
    $stageTimer = [System.Diagnostics.Stopwatch]::StartNew()
    Write-ServerLog 'GET /api/system: Windows OS query started'
    # CIM is preferred, but fall back to classic WMI on machines where the CIM provider is unavailable.
    try { $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop }
    catch {
        Write-ServerLog ('CIM OS query failed; trying WMI fallback: ' + $_.Exception.Message)
        try { $os = Get-WmiObject Win32_OperatingSystem -ErrorAction Stop }
        catch { throw ('Windows OS 정보를 읽지 못했습니다. CIM/WMI 조회 실패: ' + $_.Exception.Message) }
    }
    Write-ServerLog ('GET /api/system: OS query complete (' + [math]::Round($stageTimer.Elapsed.TotalSeconds, 2) + 's)')
    $cpu = $null
    try { $cpu = Get-CimInstance Win32_Processor -ErrorAction Stop | Select-Object -First 1 } catch {
        Write-ServerLog ('CIM CPU query failed; trying WMI fallback: ' + $_.Exception.Message)
        try { $cpu = Get-WmiObject Win32_Processor -ErrorAction Stop | Select-Object -First 1 } catch { Write-ServerLog ('WMI CPU query failed: ' + $_.Exception.Message) }
    }
    $cpuLoad = $null
    $cpuLoadSource = 'Windows Processor Information utility counter'
    # Prefer the Windows Processor Information utility counter when exposed; fall back to the standard total processor-time counter.
    try {
        $cpuUtil = Get-CimInstance Win32_PerfFormattedData_Counters_ProcessorInformation -Filter "Name='_Total'" -ErrorAction Stop | Select-Object -First 1
        if ($cpuUtil -and $null -ne $cpuUtil.PercentProcessorUtility) {
            $cpuLoad = [math]::Max([double]0, [math]::Min([double]100, [math]::Round([double]$cpuUtil.PercentProcessorUtility, 1)))
        }
    } catch { }
    if ($null -eq $cpuLoad) {
        try {
            $cpuPerf = Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -Filter "Name='_Total'" -ErrorAction Stop | Select-Object -First 1
            if ($cpuPerf -and $null -ne $cpuPerf.PercentProcessorTime) {
                $cpuLoad = [math]::Max([double]0, [math]::Min([double]100, [math]::Round([double]$cpuPerf.PercentProcessorTime, 1)))
                $cpuLoadSource = 'Windows formatted total processor-time counter (fallback)'
            }
        } catch { }
    }
    if ($null -eq $cpuLoad) {
        # Last fallback: average raw logical processor samples using each instance's own elapsed 100ns timestamp.
        try {
            $rawRows = @(Get-CimInstance Win32_PerfRawData_PerfOS_Processor -ErrorAction Stop | Where-Object { $_.Name -ne '_Total' })
            $nextCpuSamples = @{}; $coreLoads = @()
            foreach ($row in $rawRows) {
                $key = [string]$row.Name; $currentCpu = [double]$row.PercentProcessorTime; $currentTime = [double]$row.Timestamp_Sys100NS; $previous = $script:CpuRawSample[$key]
                if ($null -ne $previous) {
                    $deltaCpu = $currentCpu - [double]$previous.cpu; $deltaTime = $currentTime - [double]$previous.time
                    if ($deltaTime -gt 0 -and $deltaCpu -ge 0) { $value = (1 - ($deltaCpu / $deltaTime)) * 100; if ($value -ge -1 -and $value -le 101) { $coreLoads += [math]::Max([double]0, [math]::Min([double]100, $value)) } }
                }
                $nextCpuSamples[$key] = @{ cpu = $currentCpu; time = $currentTime }
            }
            if ($nextCpuSamples.Count -gt 0) { $script:CpuRawSample = $nextCpuSamples }
            if ($coreLoads.Count -gt 0) { $cpuLoad = [math]::Round((($coreLoads | Measure-Object -Average).Average), 1); $cpuLoadSource = 'Raw per-logical-processor counters (fallback)' }
        } catch { Write-ServerLog ("CPU counter unavailable: " + $_.Exception.Message) }
    }
    Write-ServerLog ('GET /api/system: CPU query complete (' + [math]::Round($stageTimer.Elapsed.TotalSeconds, 2) + 's)')
    # Task-Manager-like physical memory use: TotalVisibleMemorySize minus AvailableMBytes.
    $ramTotal = [math]::Round(([double]$os.TotalVisibleMemorySize / 1MB), 2)
    $ramFree = [math]::Round(([double]$os.FreePhysicalMemory / 1MB), 2)
    try {
        $memPerf = Get-CimInstance Win32_PerfFormattedData_PerfOS_Memory -ErrorAction Stop | Select-Object -First 1
        if ($memPerf -and $null -ne $memPerf.AvailableMBytes) { $ramFree = [math]::Max([double]0, [math]::Min($ramTotal, [math]::Round(([double]$memPerf.AvailableMBytes / 1024), 2))) }
    } catch {}
    $ramUsed = [math]::Max([double]0, [math]::Round($ramTotal - $ramFree, 2))
    $ramPercent = if ($ramTotal -gt 0) { [math]::Round(($ramUsed / $ramTotal) * 100, 1) } else { $null }

    if (-not $script:StaticInventory -or ((Get-Date) - $script:StaticInventoryAt).TotalSeconds -ge 300) {
        $ramModules = @(Get-CimInstance Win32_PhysicalMemory -ErrorAction SilentlyContinue | ForEach-Object {
            [pscustomobject]@{ manufacturer = [string]$_.Manufacturer; partNumber = ([string]$_.PartNumber).Trim(); capacityGB = [math]::Round(([double]$_.Capacity / 1GB), 2); speedMHz = $_.Speed }
        })
        $storageDevices = @(Get-CimInstance Win32_DiskDrive -ErrorAction SilentlyContinue | ForEach-Object {
            [pscustomobject]@{ model = [string]$_.Model; manufacturer = [string]$_.Manufacturer; interfaceType = [string]$_.InterfaceType; mediaType = [string]$_.MediaType; sizeGB = if ($_.Size) { [math]::Round(([double]$_.Size / 1GB), 1) } else { $null } }
        })
        $gpu = @(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | ForEach-Object {
            $adapterBytes = $null
            try { if ($_.AdapterRAM -and [double]$_.AdapterRAM -gt 0) { $adapterBytes = [double]$_.AdapterRAM } } catch {}
            [pscustomobject]@{
                name = [string]$_.Name; driver = [string]$_.DriverVersion
                resolution = if ($_.CurrentHorizontalResolution -and $_.CurrentVerticalResolution) { "$($_.CurrentHorizontalResolution)x$($_.CurrentVerticalResolution)" } else { "-" }
                utilization = $null; adapterRamBytes = $adapterBytes
                adapterRamGBReported = if ($adapterBytes) { [math]::Round(($adapterBytes / 1GB), 2) } else { $null }
                videoProcessor = [string]$_.VideoProcessor; pnpDeviceId = [string]$_.PNPDeviceID
                status = [string]$_.Status; bitsPerPixel = $_.CurrentBitsPerPixel
                refreshRate = $_.CurrentRefreshRate; driverDate = [string]$_.DriverDate
            }
        })
        $startup = @(Get-CimInstance Win32_StartupCommand -ErrorAction SilentlyContinue | ForEach-Object {
            [pscustomobject]@{ name = [string]$_.Name; publisher = [string]$_.User; command = [string]$_.Command; location = [string]$_.Location; status = "등록됨" }
        })
        $installed = @()
        $registryPaths = @('HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*','HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*')
        foreach ($registryPath in $registryPaths) {
            $installed += @(Get-ItemProperty $registryPath -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName } | ForEach-Object {
                [pscustomobject]@{ name = [string]$_.DisplayName; version = [string]$_.DisplayVersion; publisher = [string]$_.Publisher }
            })
        }
        $installed = @($installed | Sort-Object name -Unique | Select-Object -First 500)
        $script:StaticInventory = @{ ramModules = @($ramModules); storageDevices = @($storageDevices); gpu = @($gpu); startup = @($startup); installed = @($installed) }
        $script:StaticInventoryAt = Get-Date
    }
    Write-ServerLog ('GET /api/system: inventory query complete (' + [math]::Round($stageTimer.Elapsed.TotalSeconds, 2) + 's)')
    $ramModules = @($script:StaticInventory.ramModules)
    $storageDevices = @($script:StaticInventory.storageDevices)
    $gpu = @($script:StaticInventory.gpu)
    $startup = @($script:StaticInventory.startup)
    $installed = @($script:StaticInventory.installed)

    $disks = @(Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" -ErrorAction SilentlyContinue | Where-Object { $_.Size -gt 0 } | Sort-Object @{ Expression = { if ($_.DeviceID -eq $env:SystemDrive) { 0 } else { 1 } } }, DeviceID | ForEach-Object {
        # Calculate percentages from exact byte counters before rounding the displayed GB values.
        $totalBytes = [double]$_.Size; $freeBytes = [double]$_.FreeSpace; $usedBytes = [math]::Max([double]0, ($totalBytes - $freeBytes))
        $total = [math]::Round(($totalBytes / 1GB), 2); $free = [math]::Round(($freeBytes / 1GB), 2); $used = [math]::Round(($usedBytes / 1GB), 2)
        [pscustomobject]@{ name = [string]$_.DeviceID; volumeName = [string]$_.VolumeName; fileSystem = [string]$_.FileSystem; total = $total; used = $used; free = $free; percent = if ($totalBytes -gt 0) { [math]::Round(($usedBytes / $totalBytes) * 100, 1) } else { 0 } }
    })
    # GPU counters are optional: availability depends on Windows build and driver.
    $gpuStats = [ordered]@{ available = $false; utilization = $null; utilization3D = $null; dedicatedUsedGB = $null; sharedUsedGB = $null; dedicatedTotalGB = $null; engineCount = 0; source = 'Windows GPU performance counters'; note = 'GPU 성능 카운터를 사용할 수 없습니다.' }
    try {
        $engineRows = @(Get-CimInstance Win32_PerfFormattedData_GPUPerformanceCounters_GPUEngine -ErrorAction Stop)
        if ($engineRows.Count -gt 0) {
            # Engine counters are commonly per-process. Remove PID from the instance
            # key, sum processes on the same physical engine, then take the busiest engine.
            $engineSums = @{}
            foreach ($engine in $engineRows) {
                $util = $null
                try { if ($null -ne $engine.UtilizationPercentage) { $util = [double]$engine.UtilizationPercentage } } catch {}
                if ($null -ne $util) {
                    $instance = [string]$engine.Name
                    $engineKey = ($instance -replace '(?i)pid_\d+_', '')
                    if (-not $engineSums.ContainsKey($engineKey)) { $engineSums[$engineKey] = 0.0 }
                    $engineSums[$engineKey] += [math]::Max([double]0, $util)
                }
            }
            $engineValues = @(); $threeDValues = @()
            foreach ($engineKey in $engineSums.Keys) {
                $value = [math]::Max([double]0, [math]::Min([double]100, [double]$engineSums[$engineKey]))
                $engineValues += $value
                if ($engineKey -match '(?i)engtype_3D') { $threeDValues += $value }
            }
            if ($engineValues.Count -gt 0) {
                $gpuStats.available = $true
                # This is the busiest engine after combining process instances; it is not
                # a sum of different engines, which could exceed 100% and mislead users.
                $gpuStats.utilization = [math]::Round([double](($engineValues | Measure-Object -Maximum).Maximum), 1)
                $gpuStats.engineCount = $engineValues.Count
                if ($threeDValues.Count -gt 0) { $gpuStats.utilization3D = [math]::Round([double](($threeDValues | Measure-Object -Maximum).Maximum), 1) }
                $gpuStats.note = '프로세스별 값을 동일 엔진끼리 합산한 뒤 가장 바쁜 엔진을 표시(서로 다른 엔진 간 합산은 하지 않음)'
            }
        }
    } catch { $gpuStats.note = 'GPU 엔진 카운터를 사용할 수 없음: 드라이버/Windows 지원 여부 확인 필요' }
    try {
        $memoryRows = @(Get-CimInstance Win32_PerfFormattedData_GPUPerformanceCounters_GPUAdapterMemory -ErrorAction Stop)
        if ($memoryRows.Count -gt 0) {
            $dedicatedUsed = 0.0; $sharedUsed = 0.0; $dedicatedCommitted = 0.0
            $hasDedicated = $false; $hasShared = $false; $hasDedicatedTotal = $false
            foreach ($memoryRow in $memoryRows) {
                if ($memoryRow.PSObject.Properties['DedicatedUsage']) { $dedicatedUsed += [double]$memoryRow.DedicatedUsage; $hasDedicated = $true }
                if ($memoryRow.PSObject.Properties['SharedUsage']) { $sharedUsed += [double]$memoryRow.SharedUsage; $hasShared = $true }
                if ($memoryRow.PSObject.Properties['TotalDedicatedMemory']) { $dedicatedCommitted += [double]$memoryRow.TotalDedicatedMemory; $hasDedicatedTotal = $true }
            }
            if ($hasDedicated) { $gpuStats.dedicatedUsedGB = [math]::Round(($dedicatedUsed / 1GB), 2) }
            if ($hasShared) { $gpuStats.sharedUsedGB = [math]::Round(($sharedUsed / 1GB), 2) }
            if ($hasDedicatedTotal -and $dedicatedCommitted -gt 0) { $gpuStats.dedicatedTotalGB = [math]::Round(($dedicatedCommitted / 1GB), 2) }
        }
    } catch {}
    $gpuStats = [pscustomobject]$gpuStats
    Write-ServerLog ('GET /api/system: GPU query complete (' + [math]::Round($stageTimer.Elapsed.TotalSeconds, 2) + 's)')
    $hardwareSensors = Get-HardwareSensorData
    $cpuTempSensor = $null; $gpuTempSensor = $null
    if ($hardwareSensors.available) {
        $cpuCandidates = @($hardwareSensors.sensors | Where-Object { $_.type -match '(?i)Temperature' -and (($_.hardware + ' ' + $_.name) -match '(?i)CPU|Intel|Package|Core Max') })
        $cpuTempSensor = $cpuCandidates | Where-Object { $_.name -match '(?i)Package|CPU Package' } | Select-Object -First 1
        if (-not $cpuTempSensor) { $cpuTempSensor = $cpuCandidates | Select-Object -First 1 }
        $gpuCandidates = @($hardwareSensors.sensors | Where-Object { $_.type -match '(?i)Temperature' -and (($_.hardware + ' ' + $_.name) -match '(?i)GTX|NVIDIA|GPU') })
        $gpuTempSensor = $gpuCandidates | Where-Object { $_.name -match '(?i)GPU Core|GPU Temperature|Temperature' } | Select-Object -First 1
        if (-not $gpuTempSensor) { $gpuTempSensor = $gpuCandidates | Select-Object -First 1 }
    }
    Write-ServerLog ('GET /api/system: optional sensor query complete (' + [math]::Round($stageTimer.Elapsed.TotalSeconds, 2) + 's)')
    $diskActivity = Get-DiskActivityData
    $processNow = Get-Date
    $elapsedProcess = if ($script:LastProcessSampleAt) { ($processNow - $script:LastProcessSampleAt).TotalSeconds } else { 0 }
    $logicalCount = if ($cpu -and $cpu.NumberOfLogicalProcessors) { [math]::Max(1, [int]$cpu.NumberOfLogicalProcessors) } else { [math]::Max(1, [int]$env:NUMBER_OF_PROCESSORS) }
    $nextProcessSample = @{}
    $procs = @(Get-Process -ErrorAction SilentlyContinue | Sort-Object -Property WorkingSet64 -Descending | Select-Object -First 15 | ForEach-Object {
        $cpuSeconds = $null; $cpuPercent = $null
        try { if ($null -ne $_.CPU) { $cpuSeconds = [double]$_.CPU } } catch {}
        if ($null -ne $cpuSeconds) {
            $previous = $script:LastProcessSample[[string]$_.Id]
            if ($elapsedProcess -gt 0 -and $null -ne $previous -and $cpuSeconds -ge [double]$previous) {
                $cpuPercent = [math]::Round([math]::Max([double]0, [math]::Min([double]100, (($cpuSeconds - [double]$previous) / $elapsedProcess / $logicalCount) * 100)), 1)
            }
            $nextProcessSample[[string]$_.Id] = $cpuSeconds
        }
        [pscustomobject]@{ name = [string]$_.ProcessName + ".exe"; pid = $_.Id; cpu = $cpuPercent; mem = [math]::Round(([double]$_.WorkingSet64 / 1MB), 0) }
    })
    $script:LastProcessSample = $nextProcessSample; $script:LastProcessSampleAt = $processNow
    $netCfg = Get-NetIPConfiguration -ErrorAction SilentlyContinue | Where-Object { $_.IPv4Address } | Select-Object -First 1
    [int64]$netRx = 0; [int64]$netTx = 0
    try { $allStats = @(Get-NetAdapterStatistics -ErrorAction Stop); $netRx = [int64](($allStats | Measure-Object -Property ReceivedBytes -Sum).Sum); $netTx = [int64](($allStats | Measure-Object -Property SentBytes -Sum).Sum) } catch {}
    $now = Get-Date; $downloadMbps = $null; $uploadMbps = $null
    if ($script:LastNetSample -and $script:LastNetSampleAt) { $elapsed = ($now - $script:LastNetSampleAt).TotalSeconds; if ($elapsed -gt 0) { $downloadMbps = [math]::Round([math]::Max([double]0, (($netRx - $script:LastNetSample.rx) * 8 / $elapsed / 1000000)), 2); $uploadMbps = [math]::Round([math]::Max([double]0, (($netTx - $script:LastNetSample.tx) * 8 / $elapsed / 1000000)), 2) } }
    $script:LastNetSample = @{ rx = $netRx; tx = $netTx }; $script:LastNetSampleAt = $now
    $adapter = if ($netCfg) { [string]$netCfg.InterfaceAlias } else { "알 수 없음" }
    $ip = if ($netCfg) { [string]$netCfg.IPv4Address.IPAddress } else { "-" }
    $mask = "-"
    if ($netCfg -and $null -ne $netCfg.IPv4Address.PrefixLength) {
        $prefix = [int]$netCfg.IPv4Address.PrefixLength; $maskBytes = [byte[]]::new(4)
        for ($i = 0; $i -lt 4; $i++) { $bits = [math]::Max(0, [math]::Min(8, $prefix - ($i * 8))); $maskBytes[$i] = if ($bits -eq 0) { 0 } else { [int](256 - [math]::Pow(2, 8 - $bits)) } }
        $mask = ($maskBytes -join '.')
    }
    $gw = if ($netCfg -and $netCfg.IPv4DefaultGateway) { [string]$netCfg.IPv4DefaultGateway.NextHop } else { "-" }
    $dns = if ($netCfg -and $netCfg.DNSServer) { ($netCfg.DNSServer.ServerAddresses -join ", ") } else { "-" }
    Write-ServerLog ('GET /api/system: collection assembly complete (' + [math]::Round($stageTimer.Elapsed.TotalSeconds, 2) + 's)')
    $stageTimer.Stop()
    [pscustomobject]@{
        computer = [pscustomobject]@{ name = [string]$env:COMPUTERNAME; source = '이 프로그램을 실행 중인 Windows PC'; collectedAt = (Get-Date).ToString('o') }; os = [pscustomobject]@{ name = [string]$os.Caption; version = [string]$os.Version; build = [string]$os.BuildNumber; arch = [string]$os.OSArchitecture }
        cpu = [pscustomobject]@{ name = if ($cpu) { [string]$cpu.Name.Trim() } else { "프로세서 정보 없음" }; manufacturer = if ($cpu) { [string]$cpu.Manufacturer } else { "-" }; cores = if ($cpu) { $cpu.NumberOfCores } else { $null }; logicalProcessors = if ($cpu) { $cpu.NumberOfLogicalProcessors } else { $null }; maxClockMHz = if ($cpu) { $cpu.MaxClockSpeed } else { $null }; load = $cpuLoad; loadSource = $cpuLoadSource; temp = if ($cpuTempSensor) { [math]::Round([double]$cpuTempSensor.value,1) } else { $null }; tempSource = if ($cpuTempSensor) { 'LibreHardwareMonitor sensor: ' + $cpuTempSensor.name } else { '미지원/센서 미연결' } }
        gpu = @($gpu); gpuStats = [pscustomobject]@{ available = $gpuStats.available; utilization = $gpuStats.utilization; utilization3D = $gpuStats.utilization3D; dedicatedUsedGB = $gpuStats.dedicatedUsedGB; sharedUsedGB = $gpuStats.sharedUsedGB; dedicatedTotalGB = $gpuStats.dedicatedTotalGB; engineCount = $gpuStats.engineCount; source = $gpuStats.source; note = $gpuStats.note; temperatureC = if ($gpuTempSensor) { [math]::Round([double]$gpuTempSensor.value,1) } else { $null }; temperatureSource = if ($gpuTempSensor) { 'LibreHardwareMonitor sensor: ' + $gpuTempSensor.name } else { '미지원/센서 미연결' } }; hardwareSensors = $hardwareSensors; diskActivity = $diskActivity; networkRate = [pscustomobject]@{ downloadMbps = $downloadMbps; uploadMbps = $uploadMbps }
        ram = [pscustomobject]@{ total = $ramTotal; used = $ramUsed; free = $ramFree; percent = $ramPercent; modules = @($ramModules) }
        disks = @($disks); storageDevices = @($storageDevices); processes = @($procs); installedPrograms = @($installed); blockedPrograms = @()
        network = [pscustomobject]@{ adapter = $adapter; ip = $ip; mask = $mask; gateway = $gw; dns = $dns }; startup = @($startup)
    }
}


function Get-DeviceInventory {
    param([switch]$ForceRefresh)
    if (-not $ForceRefresh -and $script:DeviceInventoryCache -and ((Get-Date) - $script:DeviceInventoryAt).TotalSeconds -lt 20) { return $script:DeviceInventoryCache }
    $items = @()
    $classMap = @{ 'Monitor'='monitor'; 'Mouse'='mouse'; 'Keyboard'='keyboard'; 'AudioEndpoint'='audio'; 'MEDIA'='audio' }
    try {
        $pnp = @(Get-CimInstance Win32_PnPEntity -ErrorAction Stop | Where-Object {
            $n = [string]$_.Name
            $class = [string]$_.PNPClass
            $class -in @('Monitor','Mouse','Keyboard','AudioEndpoint','MEDIA') -or
            (($class -eq 'HIDClass' -or $class -eq 'USB') -and $n -match '(?i)mouse|keyboard|마우스|키보드')
        } | Where-Object { $_.Name -and $_.Name -notmatch 'Microsoft Virtual|Remote Desktop|Software Device' })
        foreach ($d in $pnp) {
            $class = [string]$d.PNPClass
            $kind = [string]$classMap[$class]
            if (-not $kind -and [string]$d.Name -match '(?i)mouse|마우스') { $kind = 'mouse' }
            if (-not $kind -and [string]$d.Name -match '(?i)keyboard|키보드') { $kind = 'keyboard' }
            if (-not $kind) { continue }
            if ($d.ConfigManagerErrorCode -and [int]$d.ConfigManagerErrorCode -ne 0) { $status = '문제 감지' } else { $status = if ($d.Status) { [string]$d.Status } else { 'Windows 감지됨' } }
            $items += [pscustomobject]@{ name=[string]$d.Name; manufacturer=[string]$d.Manufacturer; kind=$kind; status=$status; service=[string]$d.Service; pnpClass=$class; pnpDeviceId=[string]$d.PNPDeviceID; hardwareIds=(@($d.HardwareID) -join '; ') }
        }
    } catch {}
    try {
        foreach ($d in @(Get-CimInstance Win32_Keyboard -ErrorAction Stop)) {
            if ($d.Name) { $items += [pscustomobject]@{ name=[string]$d.Name; manufacturer=[string]$d.Description; kind='keyboard'; status=if ($d.Status) {[string]$d.Status} else {'Windows 감지됨'}; service=''; pnpClass='Win32_Keyboard'; pnpDeviceId=[string]$d.DeviceID; hardwareIds='' } }
        }
    } catch {}
    try {
        foreach ($d in @(Get-CimInstance Win32_PointingDevice -ErrorAction Stop)) {
            if ($d.Name) { $items += [pscustomobject]@{ name=[string]$d.Name; manufacturer=[string]$d.Manufacturer; kind='mouse'; status=if ($d.Status) {[string]$d.Status} else {'Windows 감지됨'}; service=[string]$d.DeviceInterface; pnpClass='Win32_PointingDevice'; pnpDeviceId=[string]$d.DeviceID; hardwareIds='' } }
        }
    } catch {}
    try {
        $vcs = @(Get-CimInstance Win32_VideoController -ErrorAction Stop)
        foreach ($vc in $vcs) {
            $res = if ($vc.CurrentHorizontalResolution -and $vc.CurrentVerticalResolution) { "$($vc.CurrentHorizontalResolution)x$($vc.CurrentVerticalResolution)" } else { $null }
            $refresh = if ($vc.CurrentRefreshRate -and [int]$vc.CurrentRefreshRate -gt 0) { [int]$vc.CurrentRefreshRate } else { $null }
            $mon = $items | Where-Object { $_.kind -eq 'monitor' } | Select-Object -First 1
            if ($mon) { $mon | Add-Member -NotePropertyName resolution -NotePropertyValue $res -Force; $mon | Add-Member -NotePropertyName refreshRate -NotePropertyValue $refresh -Force; $mon | Add-Member -NotePropertyName graphicsAdapter -NotePropertyValue ([string]$vc.Name) -Force }
        }
    } catch {}
    try {
        $displaySize = Get-CimInstance -Namespace root\wmi -ClassName WmiMonitorBasicDisplayParams -ErrorAction Stop | Select-Object -First 1
        if ($displaySize -and $items.Count -gt 0) {
            $mon = $items | Where-Object { $_.kind -eq 'monitor' } | Select-Object -First 1
            if ($mon -and $displaySize.MaxHorizontalImageSize -and $displaySize.MaxVerticalImageSize) {
                $mon | Add-Member -NotePropertyName physicalSize -NotePropertyValue ("약 {0} × {1} cm" -f [int]$displaySize.MaxHorizontalImageSize,[int]$displaySize.MaxVerticalImageSize) -Force
            }
        }
    } catch {}
    $mouseSpeed = 10; $accel = $false; $keyboardRepeatRate = $null; $keyboardRepeatDelay = $null
    try { $mouseKey = Get-ItemProperty 'HKCU:\Control Panel\Mouse' -ErrorAction Stop; if ([int]$mouseKey.MouseSensitivity -ge 1 -and [int]$mouseKey.MouseSensitivity -le 20) { $mouseSpeed=[int]$mouseKey.MouseSensitivity }; $accel = ([string]$mouseKey.MouseSpeed -eq '2') } catch {}
    try { $keyboardKey = Get-ItemProperty 'HKCU:\Control Panel\Keyboard' -ErrorAction Stop; if ($null -ne $keyboardKey.KeyboardSpeed) { $keyboardRepeatRate = [int]$keyboardKey.KeyboardSpeed }; if ($null -ne $keyboardKey.KeyboardDelay) { $keyboardRepeatDelay = [int]$keyboardKey.KeyboardDelay } } catch {}
    $result = @{ devices=@($items | Sort-Object kind,name -Unique); mouseSpeed=$mouseSpeed; mouseAcceleration=$accel; keyboardRepeatRate=$keyboardRepeatRate; keyboardRepeatDelay=$keyboardRepeatDelay; collectedAt=(Get-Date).ToString('o'); computerName=[string]$env:COMPUTERNAME }; $script:DeviceInventoryCache = $result; $script:DeviceInventoryAt = Get-Date; return $result
}

function Import-ExtensionInboxPackages {
    $results = @()
    foreach ($source in @(Get-ChildItem -LiteralPath $extensionInboxRoot -Filter '*.zip' -File -ErrorAction SilentlyContinue)) {
        $archive = $null
        try {
            if ($source.Length -le 0 -or $source.Length -gt 104857600) { throw '패키지 크기는 1바이트 이상 100MB 이하여야 합니다.' }
            $archive = [System.IO.Compression.ZipFile]::OpenRead($source.FullName)
            if ($archive.Entries.Count -gt 1000) { throw 'ZIP 항목은 1,000개 이하여야 합니다.' }
            $expandedSize = [long](($archive.Entries | Measure-Object -Property Length -Sum).Sum)
            if ($expandedSize -gt 524288000) { throw '압축 해제 기준 크기는 500MB 이하여야 합니다.' }
            foreach ($entry in $archive.Entries) {
                $entryName = $entry.FullName.Replace('\','/')
                if ($entryName.StartsWith('/') -or $entryName -match '(^|/)\.\.(?:/|$)' -or $entryName -match '^[A-Za-z]:') { throw '안전하지 않은 ZIP 경로가 있습니다.' }
            }
            $manifestEntry = $archive.GetEntry('manifest.json')
            if (-not $manifestEntry -or $manifestEntry.Length -gt 1048576) { throw 'ZIP 최상위에 1MB 이하 manifest.json이 필요합니다.' }
            $reader = New-Object System.IO.StreamReader($manifestEntry.Open(), [System.Text.Encoding]::UTF8)
            try { $manifest = $reader.ReadToEnd() | ConvertFrom-Json -ErrorAction Stop } finally { $reader.Dispose() }
            $extName = [string]$manifest.name; $extVersion = [string]$manifest.version
            if ([int]$manifest.manifest_version -ne 3 -or [string]::IsNullOrWhiteSpace($extName) -or $extVersion -notmatch '^\d+(\.\d+){1,3}$') { throw 'Manifest V3, 이름, 숫자 형식 버전(예: 1.0.0)이 필요합니다.' }
            $manifestKey = [string]$manifest.key
            if (-not [string]::IsNullOrWhiteSpace($manifestKey)) {
                $provider = [System.Security.Cryptography.SHA256]::Create()
                try { $keyHash = [BitConverter]::ToString($provider.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($manifestKey))); $keyHash = $keyHash.Replace('-',''); $identity = 'key-' + $keyHash.Substring(0,16).ToLowerInvariant() } finally { $provider.Dispose() }
            } else {
                $slug = ($extName.ToLowerInvariant() -replace '[^a-z0-9가-힣]+','-').Trim('-'); if ([string]::IsNullOrWhiteSpace($slug)) { $slug = 'extension' }; $identity = 'name-' + $slug
            }
            foreach ($metaPath in @(Get-ChildItem -LiteralPath $extensionRoot -Filter '*.meta.json' -File -ErrorAction SilentlyContinue)) {
                try {
                    $old = Get-Content -LiteralPath $metaPath.FullName -Raw | ConvertFrom-Json -ErrorAction Stop
                    $oldIdentity = [string]$old.identity
                    if (-not $oldIdentity) { $oldIdentity = 'name-' + (([string]$old.name).ToLowerInvariant() -replace '[^a-z0-9가-힣]+','-').Trim('-') }
                    if ($oldIdentity -eq $identity -and ([version]$extVersion) -le ([version][string]$old.version)) { throw "이미 등록된 버전($($old.version))보다 높은 버전이 필요합니다." }
                } catch { if ($_.Exception.Message -like '이미 등록된 버전*') { throw } }
            }
            $safeName = ($extName -replace '[^a-zA-Z0-9가-힣._-]','_').Trim('._-'); if ([string]::IsNullOrWhiteSpace($safeName)) { $safeName = 'extension' }
            $destName = "$safeName-v$extVersion.zip"; $destPath = Join-Path $extensionRoot $destName
            $sha = (Get-FileHash -LiteralPath $source.FullName -Algorithm SHA256).Hash
            Copy-Item -LiteralPath $source.FullName -Destination $destPath -Force
            Copy-Item -LiteralPath $source.FullName -Destination (Join-Path $extensionDownloadRoot $destName) -Force
            $meta = @{ schemaVersion = 1; identity = $identity; name = $extName; description = [string]$manifest.description; version = $extVersion; manifestVersion = 3; filename = $destName; size = [long]$source.Length; sha256 = $sha; uploadedAt = (Get-Date).ToString('yyyy-MM-dd HH:mm'); releaseNotes = @() }
            $metaPath = Join-Path $extensionRoot ($destName + '.meta.json')
            $meta | ConvertTo-Json -Compress | Set-Content -LiteralPath ($metaPath + '.tmp') -Encoding UTF8
            Move-Item -LiteralPath ($metaPath + '.tmp') -Destination $metaPath -Force
            Remove-Item -LiteralPath $source.FullName -Force
            $results += [pscustomobject]@{ filename = $source.Name; success = $true; name = $extName; version = $extVersion; message = '등록 완료' }
        } catch {
            $results += [pscustomobject]@{ filename = $source.Name; success = $false; message = $_.Exception.Message }
        } finally { if ($archive) { $archive.Dispose() } }
    }
    return $results
}

$listener = New-Object System.Net.HttpListener
$started = $false
$lastListenerError = $null
for ($p = $Port; $p -lt ($Port + 50); $p++) {
    try {
        $listener.Prefixes.Clear()
        $listener.Prefixes.Add("http://127.0.0.1:$p/")
        $listener.Start()
        $Port = $p
        $started = $true
        break
    } catch {
        $lastListenerError = $_.Exception.Message
        Write-ServerLog ("포트 $p 바인딩 실패: $lastListenerError")
    }
}
if (-not $started) {
    $message = "포트 $Port~$($Port + 49)에서 로컬 HTTP 서버를 시작하지 못했습니다. 다른 ServerService 프로세스, 보안 프로그램 또는 URL 예약/권한을 확인하세요. 마지막 오류: $lastListenerError"
    Write-ServerLog $message
    Write-Host $message -ForegroundColor Red
    Write-Host "로그: $script:ServerLogPath" -ForegroundColor Yellow
    Read-Host "Enter 키를 누르면 종료합니다"
    exit 1
}
Write-ServerLog "서버 시작: http://127.0.0.1:$Port/ (PID=$PID, Root=$root)"
Write-Host "ServerService running at http://127.0.0.1:$Port/"
$url = "http://127.0.0.1:$Port/"
$edge = "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe"
$edge64 = "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe"
$chrome = "$env:ProgramFiles\Google\Chrome\Application\chrome.exe"
$chrome86 = "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe"
if (Test-Path $edge) { Start-Process $edge -ArgumentList "--app=$url","--window-size=1280,820" }
elseif (Test-Path $edge64) { Start-Process $edge64 -ArgumentList "--app=$url","--window-size=1280,820" }
elseif (Test-Path $chrome) { Start-Process $chrome -ArgumentList "--app=$url","--window-size=1280,820" }
elseif (Test-Path $chrome86) { Start-Process $chrome86 -ArgumentList "--app=$url","--window-size=1280,820" }
else { Start-Process $url }

while ($listener.IsListening) {
    try { $ctx = $listener.GetContext() } catch {
        if ($listener.IsListening) { Write-ServerLog ("요청 수신 루프 오류: $($_.Exception.Message)") }
        break
    }
    $req = $ctx.Request
    $res = $ctx.Response
    # Security headers for all responses. The service is intentionally loopback-only.
    $res.Headers['X-Content-Type-Options'] = 'nosniff'
    $res.Headers['X-Frame-Options'] = 'DENY'
    $res.Headers['Referrer-Policy'] = 'no-referrer'
    $res.Headers['Cache-Control'] = 'no-store'
    $res.Headers['Content-Security-Policy'] = "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'"
    try {
        if ($req.HttpMethod -notin @('GET','POST','HEAD')) { $res.StatusCode = 405; $res.AddHeader('Allow','GET, POST, HEAD'); $res.Close(); continue }
        if ($req.ContentLength64 -gt 524288000) { $res.StatusCode = 413; $res.Close(); continue }
        if ($req.Url.AbsolutePath -eq "/api/admin/login" -and $req.HttpMethod -eq "POST") {
            if ((Get-Date) -lt $script:LoginLockedUntil) { $res.StatusCode = 429; $out = @{ error = "로그인 시도가 너무 많습니다. 잠시 후 다시 시도하세요." } }
            else {
                if ($req.ContentLength64 -gt 8192) { $res.StatusCode = 413; $out = @{ error = "요청이 너무 큽니다." } }
                else {
                    $reader = New-Object System.IO.StreamReader($req.InputStream, $req.ContentEncoding)
                    try { $body = $reader.ReadToEnd(); $payload = $body | ConvertFrom-Json -ErrorAction Stop } finally { $reader.Dispose() }
                    $candidate = [System.Security.Cryptography.SHA256]::Create()
                    try { $hashBytes = $candidate.ComputeHash([System.Text.Encoding]::UTF8.GetBytes([string]$payload.password)); $hash = ([BitConverter]::ToString($hashBytes)).Replace("-", "") }
                    finally { $candidate.Dispose() }
                    if ($hash -ne $script:AdminPasswordHash) {
                        $script:LoginFailures++
                        if ($script:LoginFailures -ge 5) { $script:LoginLockedUntil = (Get-Date).AddMinutes(5); $script:LoginFailures = 0 }
                        $res.StatusCode = 401; $out = @{ error = "비밀번호가 올바르지 않습니다." }
                    } else {
                        $script:LoginFailures = 0; $script:LoginLockedUntil = [datetime]::MinValue
                        $script:AdminToken = [guid]::NewGuid().ToString("N") + [guid]::NewGuid().ToString("N")
                        $script:AdminTokenExpires = (Get-Date).AddMinutes(15)
                        $out = @{ token = $script:AdminToken; expiresInSeconds = 900 }
                    }
                }
            }
            $bytes = [System.Text.Encoding]::UTF8.GetBytes(($out | ConvertTo-Json -Compress)); $res.ContentType = "application/json; charset=utf-8"; $res.ContentLength64 = $bytes.Length; $res.OutputStream.Write($bytes,0,$bytes.Length)
        }
        elseif ($req.Url.AbsolutePath -eq "/api/admin/upload" -and $req.HttpMethod -eq "POST") {
            if (-not $script:AdminToken -or (Get-Date) -ge $script:AdminTokenExpires -or $req.Headers["X-Admin-Token"] -ne $script:AdminToken) { $res.StatusCode = 401; $out = @{ error = "개발자 로그인이 필요합니다." } }
            else {
                $version = [string]$req.QueryString["version"]; $filename = [string]$req.QueryString["filename"]
                if ($version -notmatch '^\d+(\.\d+){1,3}$' -or [string]::IsNullOrWhiteSpace($filename) -or [IO.Path]::GetExtension($filename).ToLower() -notin @('.exe','.zip')) { $res.StatusCode = 400; $out = @{ error = "버전 또는 파일 형식이 올바르지 않습니다." } }
                elseif ([version]$version -le [version]$script:AppVersion) { $res.StatusCode = 400; $out = @{ error = "업데이트 버전은 현재 앱 버전 v$script:AppVersion보다 높아야 합니다." } }
                elseif ($req.ContentLength64 -gt 524288000) { $res.StatusCode = 413; $out = @{ error = "파일은 500MB 이하만 가능합니다." } }
                else {
                    $metaPath = Join-Path $uploadRoot 'update.json'
                    if (Test-Path -LiteralPath $metaPath -PathType Leaf) {
                        try {
                            $currentMeta = Get-Content -LiteralPath $metaPath -Raw | ConvertFrom-Json -ErrorAction Stop
                            $vNew = [version]$version
                            $vOld = [version][string]$currentMeta.version
                            if ($vNew -le $vOld) {
                                $res.StatusCode = 409
                                $out = @{ error = "업데이트 버전은 기존 버전보다 높아야 합니다." }
                            }
                        } catch {
                            $res.StatusCode = 500
                            $out = @{ error = "기존 업데이트 메타데이터를 읽을 수 없습니다. 메타데이터를 확인한 뒤 다시 시도하세요." }
                        }
                    }
                    if ($res.StatusCode -eq 200) {
                        $safeName = [IO.Path]::GetFileName($filename); $destName = "ServerService_v$version" + [IO.Path]::GetExtension($safeName).ToLower(); $dest = Join-Path $uploadRoot $destName
                        $tempPath = Join-Path $uploadRoot ([guid]::NewGuid().ToString('N') + '.uploading')
                        $stream = [IO.File]::Create($tempPath)
                        try {
                            $buffer = New-Object byte[] 65536; [long]$total = 0
                            while (($read = $req.InputStream.Read($buffer,0,$buffer.Length)) -gt 0) { $total += $read; if ($total -gt 524288000) { throw 'upload_too_large' }; $stream.Write($buffer,0,$read) }
                        } finally { $stream.Dispose() }
                        if ($total -eq 0) { Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue; throw 'empty_upload' }
                        $sha = (Get-FileHash -LiteralPath $tempPath -Algorithm SHA256).Hash
                        Move-Item -LiteralPath $tempPath -Destination $dest -Force
                        $releaseNotes = @(([string]$req.QueryString['notes'] -split '\r?\n') | ForEach-Object { $_.Trim() } | Where-Object { $_ } | Select-Object -First 10)
                        $meta = @{ schemaVersion = 1; product = 'ServerService'; version = $version; filename = $destName; sha256 = $sha; size = $total; fileType = [IO.Path]::GetExtension($destName).TrimStart('.').ToLower(); releaseNotes = @($releaseNotes); uploadedAt = (Get-Date).ToString('o') }
                        $meta | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath ($metaPath + '.tmp') -Encoding UTF8
                        Move-Item -LiteralPath ($metaPath + '.tmp') -Destination $metaPath -Force
                        $out = @{ success = $true; version = $version; filename = $destName; sha256 = $sha; size = $total; releaseNotes = @($releaseNotes) }; $script:AdminToken = $null; $script:AdminTokenExpires = [datetime]::MinValue
                    }
                }
            }
            $bytes = [System.Text.Encoding]::UTF8.GetBytes(($out | ConvertTo-Json -Compress)); $res.ContentType = "application/json; charset=utf-8"; $res.ContentLength64 = $bytes.Length; $res.OutputStream.Write($bytes,0,$bytes.Length)
        }
        elseif (($req.Url.AbsolutePath -eq "/api/admin/extensions/upload" -or $req.Url.AbsolutePath -eq "/api/extensions/upload") -and $req.HttpMethod -eq "POST") {
            if ($req.Url.AbsolutePath -eq "/api/admin/extensions/upload" -and (-not $script:AdminToken -or (Get-Date) -ge $script:AdminTokenExpires -or $req.Headers["X-Admin-Token"] -ne $script:AdminToken)) { $res.StatusCode = 401; $out = @{ error = "개발자 로그인이 필요합니다." } }
            elseif ([IO.Path]::GetExtension([string]$req.QueryString["filename"]).ToLower() -ne '.zip') { $res.StatusCode = 400; $out = @{ error = "확장프로그램은 .zip 패키지만 등록할 수 있습니다." } }
            elseif ($req.ContentLength64 -le 0 -or $req.ContentLength64 -gt 104857600) { $res.StatusCode = 413; $out = @{ error = "패키지 크기는 100MB 이하이며 빈 파일일 수 없습니다." } }
            else {
                $tempPath = Join-Path $extensionRoot ([guid]::NewGuid().ToString('N') + '.uploading')
                $stream = [IO.File]::Create($tempPath)
                try {
                    $buffer = New-Object byte[] 65536; [long]$total = 0
                    while (($read = $req.InputStream.Read($buffer,0,$buffer.Length)) -gt 0) { $total += $read; if ($total -gt 104857600) { throw 'extension_too_large' }; $stream.Write($buffer,0,$read) }
                } finally { $stream.Dispose() }
                if ($total -le 0) { Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue; throw 'empty_extension' }
                $archive = $null
                try {
                    $archive = [System.IO.Compression.ZipFile]::OpenRead($tempPath)
                    if ($archive.Entries.Count -gt 1000) { throw 'too_many_entries' }
                    $expandedSize = [long](($archive.Entries | Measure-Object -Property Length -Sum).Sum)
                    if ($expandedSize -gt 524288000) { throw 'zip_expanded_too_large' }
                    $entries = @($archive.Entries | ForEach-Object { $_.FullName.Replace('\','/') })
                    foreach ($entryName in $entries) { if ($entryName.StartsWith('/') -or $entryName -match '(^|/)\.\.(?:/|$)' -or $entryName -match '^[A-Za-z]:') { throw 'unsafe_zip_path' } }
                    $manifestEntry = $archive.GetEntry('manifest.json')
                    if (-not $manifestEntry) { throw 'missing_manifest' }
                    if ($manifestEntry.Length -gt 1048576) { throw 'invalid_manifest' }
                    $reader = New-Object System.IO.StreamReader($manifestEntry.Open(), [System.Text.Encoding]::UTF8)
                    try { $manifest = $reader.ReadToEnd() | ConvertFrom-Json -ErrorAction Stop } finally { $reader.Dispose() }
                    if ([int]$manifest.manifest_version -ne 3 -or [string]::IsNullOrWhiteSpace([string]$manifest.name) -or [string]$manifest.version -notmatch '^\d+(\.\d+){1,3}$') { throw 'invalid_manifest' }
                    $extName = [string]$manifest.name
                    $extVersion = [string]$manifest.version
                    $extDescription = [string]$manifest.description
                    $manifestKey = [string]$manifest.key
                    if (-not [string]::IsNullOrWhiteSpace($manifestKey)) {
                        $sha256Provider = [System.Security.Cryptography.SHA256]::Create()
                        try { $keyHash = ([BitConverter]::ToString($sha256Provider.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($manifestKey)))).Replace('-','') } finally { $sha256Provider.Dispose() }
                        $identity = 'key-' + $keyHash.Substring(0,16).ToLowerInvariant()
                    } else {
                        $identitySlug = ($extName.ToLowerInvariant() -replace '[^a-z0-9가-힣]+','-').Trim('-')
                        if ([string]::IsNullOrWhiteSpace($identitySlug)) { $identitySlug = 'extension' }
                        $identity = 'name-' + $identitySlug
                    }
                } catch {
                    Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue
                    $res.StatusCode = 400
                    $reason = switch -Regex ($_.Exception.Message) { 'missing_manifest' { '패키지 루트에 manifest.json이 없습니다.' } 'invalid_manifest' { 'Manifest V3 manifest.json에 이름과 유효한 버전이 필요합니다.' } 'unsafe_zip_path' { 'ZIP에 안전하지 않은 경로가 포함되어 있습니다.' } 'too_many_entries' { 'ZIP 파일 항목은 1,000개 이하만 허용됩니다.' } 'zip_expanded_too_large' { '압축 해제 기준 패키지 크기는 500MB 이하만 허용됩니다.' } default { '올바른 확장프로그램 ZIP 패키지를 읽지 못했습니다.' } }
                    $out = @{ error = $reason }
                } finally { if ($archive) { $archive.Dispose() } }
                if ($res.StatusCode -eq 200) {
                    foreach ($existingMetaPath in (Get-ChildItem -LiteralPath $extensionRoot -Filter '*.meta.json' -File -ErrorAction SilentlyContinue)) {
                        try {
                            $existingMeta = Get-Content -LiteralPath $existingMetaPath.FullName -Raw | ConvertFrom-Json -ErrorAction Stop
                            $existingIdentity = [string]$existingMeta.identity
                            if (-not $existingIdentity) { $existingIdentity = 'name-' + (([string]$existingMeta.name).ToLowerInvariant() -replace '[^a-z0-9가-힣]+','-').Trim('-') }
                            if ($existingIdentity -eq $identity -and ([version]$extVersion) -le ([version][string]$existingMeta.version)) {
                                $res.StatusCode = 409
                                $out = @{ error = '같은 확장프로그램의 새 버전은 등록된 버전보다 높아야 합니다.' }
                                break
                            }
                        } catch {}
                    }
                }
                if ($res.StatusCode -ne 200) { Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue }
                if ($res.StatusCode -eq 200) {
                    $safeName = ($extName -replace '[^a-zA-Z0-9가-힣._-]','_').Trim('._-'); if ([string]::IsNullOrWhiteSpace($safeName)) { $safeName = 'extension' }
                    $destName = "$safeName-v$extVersion.zip"; $destPath = Join-Path $extensionRoot $destName
                    $sha = (Get-FileHash -LiteralPath $tempPath -Algorithm SHA256).Hash
                    Move-Item -LiteralPath $tempPath -Destination $destPath -Force
                    Copy-Item -LiteralPath $destPath -Destination (Join-Path $extensionDownloadRoot $destName) -Force
                    $meta = @{ schemaVersion = 1; identity = $identity; name = $extName; description = $extDescription; version = $extVersion; manifestVersion = 3; filename = $destName; size = $total; sha256 = $sha; uploadedAt = (Get-Date).ToString('yyyy-MM-dd HH:mm'); releaseNotes = @() }
                    $metaPath = Join-Path $extensionRoot ($destName + '.meta.json')
                    $meta | ConvertTo-Json -Compress | Set-Content -LiteralPath ($metaPath + '.tmp') -Encoding UTF8
                    Move-Item -LiteralPath ($metaPath + '.tmp') -Destination $metaPath -Force
                    $out = @{ success = $true; name = $extName; version = $extVersion; filename = $destName; size = $total; sha256 = $sha }
                    $script:AdminToken = $null; $script:AdminTokenExpires = [datetime]::MinValue
                }
            }
            $bytes = [System.Text.Encoding]::UTF8.GetBytes(($out | ConvertTo-Json -Compress)); $res.ContentType = "application/json; charset=utf-8"; $res.ContentLength64 = $bytes.Length; $res.OutputStream.Write($bytes,0,$bytes.Length)
        }
        elseif ($req.Url.AbsolutePath -eq "/api/admin/password" -and $req.HttpMethod -eq "POST") {
            if (-not $script:AdminToken -or (Get-Date) -ge $script:AdminTokenExpires -or $req.Headers["X-Admin-Token"] -ne $script:AdminToken) { $res.StatusCode = 401; $out = @{ error = "개발자 로그인이 필요합니다." } }
            elseif ($req.ContentLength64 -gt 8192) { $res.StatusCode = 413; $out = @{ error = "요청이 너무 큽니다." } }
            else {
                $reader = New-Object System.IO.StreamReader($req.InputStream, $req.ContentEncoding)
                try { $payload = ($reader.ReadToEnd() | ConvertFrom-Json -ErrorAction Stop) } finally { $reader.Dispose() }
                $newPassword = [string]$payload.password
                if ($newPassword.Length -lt 8 -or $newPassword.Length -gt 128) { $res.StatusCode = 400; $out = @{ error = "새 비밀번호는 8~128자여야 합니다." } }
                else {
                    $sha256 = [System.Security.Cryptography.SHA256]::Create()
                    try { $newHash = ([BitConverter]::ToString($sha256.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($newPassword)))).Replace('-', '') } finally { $sha256.Dispose() }
                    @{ passwordHash = $newHash; updatedAt = (Get-Date).ToString('o') } | ConvertTo-Json -Compress | Set-Content -LiteralPath ($adminConfigPath + '.tmp') -Encoding UTF8
                    Move-Item -LiteralPath ($adminConfigPath + '.tmp') -Destination $adminConfigPath -Force
                    $script:AdminPasswordHash = $newHash; $out = @{ success = $true; message = "비밀번호를 변경했습니다. 새 비밀번호로 다시 로그인하세요." }
                    $script:AdminToken = $null; $script:AdminTokenExpires = [datetime]::MinValue
                }
            }
            $bytes = [System.Text.Encoding]::UTF8.GetBytes(($out | ConvertTo-Json -Compress)); $res.ContentType = "application/json; charset=utf-8"; $res.ContentLength64 = $bytes.Length; $res.OutputStream.Write($bytes,0,$bytes.Length)
        }
        elseif ($req.Url.AbsolutePath -eq "/api/admin/status" -and $req.HttpMethod -eq "GET") {
            if (-not $script:AdminToken -or (Get-Date) -ge $script:AdminTokenExpires -or $req.Headers["X-Admin-Token"] -ne $script:AdminToken) { $res.StatusCode = 401; $out = @{ error = "개발자 로그인이 필요합니다." } }
            else { $identity = [Security.Principal.WindowsIdentity]::GetCurrent(); $principal = New-Object Security.Principal.WindowsPrincipal($identity); $out = @{ authenticated = $true; elevated = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator); user = $identity.Name; expiresAt = $script:AdminTokenExpires.ToString('o') } }
            $bytes = [System.Text.Encoding]::UTF8.GetBytes(($out | ConvertTo-Json -Compress)); $res.ContentType = "application/json; charset=utf-8"; $res.ContentLength64 = $bytes.Length; $res.OutputStream.Write($bytes,0,$bytes.Length)
        }
        elseif ($req.Url.AbsolutePath -eq "/api/admin/action" -and $req.HttpMethod -eq "POST") {
            if (-not $script:AdminToken -or (Get-Date) -ge $script:AdminTokenExpires -or $req.Headers["X-Admin-Token"] -ne $script:AdminToken) { $res.StatusCode = 401; $out = @{ error = "개발자 로그인이 필요합니다." } }
            elseif ($req.ContentLength64 -gt 8192) { $res.StatusCode = 413; $out = @{ error = "요청이 너무 큽니다." } }
            else {
                $reader = New-Object System.IO.StreamReader($req.InputStream, $req.ContentEncoding)
                try { $payload = ($reader.ReadToEnd() | ConvertFrom-Json -ErrorAction Stop) } finally { $reader.Dispose() }
                $action = [string]$payload.action
                switch ($action) {
                    'startup-settings' { Start-Process 'ms-settings:startupapps'; $out = @{ success = $true; message = 'Windows 시작 앱 설정을 열었습니다.' } }
                    'task-manager' { Start-Process 'taskmgr.exe'; $out = @{ success = $true; message = '작업 관리자를 열었습니다.' } }
                    'windows-security' { Start-Process 'windowsdefender:'; $out = @{ success = $true; message = 'Windows 보안을 열었습니다.' } }
                    'installed-apps' { Start-Process 'ms-settings:appsfeatures'; $out = @{ success = $true; message = '설치된 앱 설정을 열었습니다.' } }
                    'network-settings' { Start-Process 'ms-settings:network'; $out = @{ success = $true; message = '네트워크 설정을 열었습니다.' } }
                    default { $res.StatusCode = 400; $out = @{ error = '허용되지 않은 관리자 작업입니다.' } }
                }
            }
            $bytes = [System.Text.Encoding]::UTF8.GetBytes(($out | ConvertTo-Json -Compress)); $res.ContentType = "application/json; charset=utf-8"; $res.ContentLength64 = $bytes.Length; $res.OutputStream.Write($bytes,0,$bytes.Length)
        }
        elseif ($req.Url.AbsolutePath -eq "/api/extensions/import-folder" -and $req.HttpMethod -eq "POST") {
            $results = @(Import-ExtensionInboxPackages)
            $successResults = @($results | Where-Object { $_.success })
            $failedResults = @($results | Where-Object { -not $_.success })
            $out = @{ success = $true; results = @($results); imported = $successResults.Count; failed = $failedResults.Count }
            $bytes = [System.Text.Encoding]::UTF8.GetBytes(($out | ConvertTo-Json -Depth 5 -Compress)); $res.ContentType = "application/json; charset=utf-8"; $res.ContentLength64 = $bytes.Length; $res.OutputStream.Write($bytes,0,$bytes.Length)
        }
        elseif ($req.Url.AbsolutePath -eq "/api/extensions/catalog" -and $req.HttpMethod -eq "GET") {
            $groups = @{}
            foreach ($metaPath in (Get-ChildItem -LiteralPath $extensionRoot -Filter '*.meta.json' -File -ErrorAction SilentlyContinue)) {
                try {
                    $meta = Get-Content -LiteralPath $metaPath.FullName -Raw | ConvertFrom-Json -ErrorAction Stop
                    $fn = [IO.Path]::GetFileName([string]$meta.filename)
                    if (-not $fn -or -not (Test-Path -LiteralPath (Join-Path $extensionRoot $fn) -PathType Leaf)) { continue }
                    $id = [string]$meta.identity
                    if (-not $id) { $id = 'name-' + (([string]$meta.name).ToLowerInvariant() -replace '[^a-z0-9가-힣]+','-').Trim('-') }
                    if (-not $groups.ContainsKey($id)) { $groups[$id] = @() }
                    $groups[$id] += [pscustomobject]@{ id = $id; name = [string]$meta.name; description = [string]$meta.description; version = [string]$meta.version; filename = $fn; size = [long]$meta.size; sha256 = [string]$meta.sha256; uploadedAt = [string]$meta.uploadedAt; releaseNotes = @($meta.releaseNotes); fileUrl = '/extensions/' + [uri]::EscapeDataString($fn) }
                } catch {}
            }
            $catalog = @()
            foreach ($id in $groups.Keys) {
                $versions = @($groups[$id] | Sort-Object { $parts = ([string]$_.version).Split('.'); while ($parts.Count -lt 4) { $parts += '0' }; try { [version]($parts -join '.') } catch { [version]'0.0.0.0' } } -Descending)
                if ($versions.Count -gt 0) { $latest = $versions[0]; $catalog += [pscustomobject]@{ id = $id; name = $latest.name; description = $latest.description; latestVersion = $latest.version; packageUrl = $latest.fileUrl; sha256 = $latest.sha256; size = $latest.size; uploadedAt = $latest.uploadedAt; releaseNotes = @($latest.releaseNotes); versions = @($versions | ForEach-Object { [string]$_.version }) } }
            }
            $payload = @{ schemaVersion = 1; generatedAt = (Get-Date).ToString('o'); extensions = @($catalog) }
            $bytes = [System.Text.Encoding]::UTF8.GetBytes(($payload | ConvertTo-Json -Depth 6 -Compress)); $res.ContentType = 'application/json; charset=utf-8'; $res.ContentLength64 = $bytes.Length; $res.OutputStream.Write($bytes,0,$bytes.Length)
        }
        elseif ($req.Url.AbsolutePath -eq "/api/extensions" -and $req.HttpMethod -eq "GET") {
            $null = Import-ExtensionInboxPackages
            $items = @()
            foreach ($metaPath in (Get-ChildItem -LiteralPath $extensionRoot -Filter '*.meta.json' -File -ErrorAction SilentlyContinue)) {
                try { $meta = Get-Content -LiteralPath $metaPath.FullName -Raw | ConvertFrom-Json; $fn = [IO.Path]::GetFileName([string]$meta.filename); if ($fn -and (Test-Path -LiteralPath (Join-Path $extensionRoot $fn) -PathType Leaf)) { $items += [pscustomobject]@{ id = [string]$meta.identity; name = [string]$meta.name; description = [string]$meta.description; version = [string]$meta.version; filename = $fn; size = [long]$meta.size; uploadedAt = [string]$meta.uploadedAt; sha256 = [string]$meta.sha256; fileUrl = '/extensions/' + [uri]::EscapeDataString($fn) } } } catch {}
            }
            $bytes = [System.Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject @($items) -Depth 4 -Compress)); $res.ContentType = "application/json; charset=utf-8"; $res.ContentLength64 = $bytes.Length; $res.OutputStream.Write($bytes,0,$bytes.Length)
        }
        elseif ($req.Url.AbsolutePath.StartsWith('/extensions/')) {
            $name = [IO.Path]::GetFileName([uri]::UnescapeDataString($req.Url.AbsolutePath.Substring(12)))
            if (-not $name.EndsWith('.zip',[StringComparison]::OrdinalIgnoreCase)) { $res.StatusCode = 404 }
            else { $filePath = Join-Path $extensionRoot $name; if (Test-Path -LiteralPath $filePath -PathType Leaf) { $bytes = [IO.File]::ReadAllBytes($filePath); $res.ContentType = 'application/zip'; $res.AddHeader('Content-Disposition', 'attachment; filename="' + $name.Replace('"','') + '"'); $res.ContentLength64 = $bytes.Length; $res.OutputStream.Write($bytes,0,$bytes.Length) } else { $res.StatusCode = 404 } }
        }
        elseif ($req.Url.AbsolutePath -eq "/api/update" -and $req.HttpMethod -eq "GET") {
            $metaPath = Join-Path $uploadRoot 'update.json'; $out = @{ available = $false }
            if (Test-Path $metaPath) { try { $meta = Get-Content -LiteralPath $metaPath -Raw | ConvertFrom-Json; $filePath = Join-Path $uploadRoot ([IO.Path]::GetFileName([string]$meta.filename)); if ($meta.version -and (Test-Path $filePath -PathType Leaf)) { $out = @{ schemaVersion = 1; available = $true; product = [string]$meta.product; version = [string]$meta.version; fileType = [string]$meta.fileType; fileUrl = "/updates/" + [uri]::EscapeDataString([IO.Path]::GetFileName($filePath)); sha256 = [string]$meta.sha256; size = [long]$meta.size; releaseNotes = @($meta.releaseNotes); uploadedAt = [string]$meta.uploadedAt } } } catch {} }
            $bytes = [System.Text.Encoding]::UTF8.GetBytes(($out | ConvertTo-Json -Compress)); $res.ContentType = "application/json; charset=utf-8"; $res.ContentLength64 = $bytes.Length; $res.OutputStream.Write($bytes,0,$bytes.Length)
        }
        elseif ($req.Url.AbsolutePath.StartsWith("/updates/")) {
            $name = [IO.Path]::GetFileName($req.Url.AbsolutePath.Substring(9)); $filePath = Join-Path $uploadRoot $name
            if (Test-Path $filePath -PathType Leaf) { $bytes = [IO.File]::ReadAllBytes($filePath); $res.ContentLength64 = $bytes.Length; $res.ContentType = if ($name.EndsWith('.exe')) { 'application/vnd.microsoft.portable-executable' } else { 'application/zip' }; $res.AddHeader('Content-Disposition', 'attachment; filename="' + $name.Replace('"','') + '"'); $res.OutputStream.Write($bytes,0,$bytes.Length) } else { $res.StatusCode = 404 }
        }
        elseif ($req.Url.AbsolutePath -eq "/api/devices" -and $req.HttpMethod -eq "GET") {
            $forceDeviceRefresh = $req.Url.Query -match '(^|&)refresh=1(&|$)'
            $data = Get-DeviceInventory -ForceRefresh:$forceDeviceRefresh
            $bytes = [System.Text.Encoding]::UTF8.GetBytes(($data | ConvertTo-Json -Depth 5 -Compress))
            $res.ContentType = "application/json; charset=utf-8"; $res.ContentLength64 = $bytes.Length; $res.OutputStream.Write($bytes,0,$bytes.Length)
        }
        elseif ($req.Url.AbsolutePath -eq "/api/device-settings/mouse" -and $req.HttpMethod -eq "POST") {
            if ($req.ContentLength64 -gt 8192) { $res.StatusCode = 413; $out = @{ error = '요청이 너무 큽니다.' } }
            else {
                $reader = New-Object System.IO.StreamReader($req.InputStream, $req.ContentEncoding)
                try { $payload = $reader.ReadToEnd() | ConvertFrom-Json -ErrorAction Stop } finally { $reader.Dispose() }
                $speed = 0; if (-not [int]::TryParse([string]$payload.pointerSpeed, [ref]$speed) -or $speed -lt 1 -or $speed -gt 20) { $res.StatusCode = 400; $out = @{ error = '포인터 속도는 1~20 범위여야 합니다.' } }
                else {
                    try {
                        $mousePath = 'HKCU:\Control Panel\Mouse'; $speedText = [string]$speed; $accelText = if ($payload.acceleration -eq $true) { '2' } else { '0' }
                        Set-ItemProperty -LiteralPath $mousePath -Name MouseSensitivity -Value $speedText -ErrorAction Stop
                        Set-ItemProperty -LiteralPath $mousePath -Name MouseSpeed -Value $accelText -ErrorAction Stop
                        if ($accelText -eq '0') { Set-ItemProperty -LiteralPath $mousePath -Name MouseThreshold1 -Value '0' -ErrorAction SilentlyContinue; Set-ItemProperty -LiteralPath $mousePath -Name MouseThreshold2 -Value '0' -ErrorAction SilentlyContinue } else { Set-ItemProperty -LiteralPath $mousePath -Name MouseThreshold1 -Value '6' -ErrorAction SilentlyContinue; Set-ItemProperty -LiteralPath $mousePath -Name MouseThreshold2 -Value '10' -ErrorAction SilentlyContinue }
                        $native = @'
using System;
using System.Runtime.InteropServices;
public static class ServerServiceMouseNative {
 [DllImport("user32.dll", SetLastError=true)] public static extern bool SystemParametersInfo(uint action, uint param, IntPtr value, uint winIni);
 [DllImport("user32.dll", SetLastError=true)] public static extern bool SystemParametersInfo(uint action, uint param, int[] value, uint winIni);
 [DllImport("user32.dll", SetLastError=true)] public static extern bool SystemParametersInfo(uint action, uint param, ref int value, uint winIni);
}
'@
                        if (-not ([System.Management.Automation.PSTypeName]'ServerServiceMouseNative').Type) { Add-Type -TypeDefinition $native -ErrorAction Stop }
                        $mouseArray = [int[]]@(0,0,0); if ($accelText -eq '2') { $mouseArray = [int[]]@(6,10,1) }
                        [void][ServerServiceMouseNative]::SystemParametersInfo(0x0004,0,$mouseArray,0x0002)
                        $speedValue = [int]$speed; [void][ServerServiceMouseNative]::SystemParametersInfo(0x0071,0,[ref]$speedValue,0x0002)
                        $out = @{ success = $true; message = "Windows 포인터 속도를 $speed/20으로 설정했습니다. 실제 하드웨어 DPI는 변경되지 않았습니다." }
                    } catch { $res.StatusCode = 500; $out = @{ error = 'Windows 포인터 설정을 적용하지 못했습니다. ' + $_.Exception.Message } }
                }
            }
            $bytes = [System.Text.Encoding]::UTF8.GetBytes(($out | ConvertTo-Json -Compress)); $res.ContentType = 'application/json; charset=utf-8'; $res.ContentLength64 = $bytes.Length; $res.OutputStream.Write($bytes,0,$bytes.Length)
        }
        elseif ($req.Url.AbsolutePath -eq "/api/device-profile/apply" -and $req.HttpMethod -eq "POST") {
            if ($req.ContentLength64 -gt 8192) { $res.StatusCode = 413; $out = @{ error = '요청이 너무 큽니다.' } }
            else {
                $reader = New-Object System.IO.StreamReader($req.InputStream, $req.ContentEncoding)
                try { $payload = $reader.ReadToEnd() | ConvertFrom-Json -ErrorAction Stop } finally { $reader.Dispose() }
                $genre = [string]$payload.genre
                if ($genre -notin @('fps','rpg','story_high','story_low')) { $res.StatusCode = 400; $out = @{ error = '지원하지 않는 게임 장르입니다.' } }
                else {
                    $configDir = Join-Path $env:LOCALAPPDATA 'ServerService'; New-Item -ItemType Directory -Path $configDir -Force | Out-Null
                    $profilePath = Join-Path $configDir 'device-profile.json'
                    $names = @{ fps='FPS'; rpg='RPG'; story_high='고퀄리티 스토리'; story_low='저사양 스토리' }
                    $profile = @{ genre=$genre; genreLabel=$names[$genre]; savedAt=(Get-Date).ToString('o'); note='추천 프로필 저장됨. NVIDIA 드라이버 설정은 NVIDIA 제어판에서 확인 후 적용해야 함.' }
                    $profile | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $profilePath -Encoding UTF8
                    $nvcpl = @("$env:ProgramFiles\NVIDIA Corporation\Control Panel Client\nvcplui.exe", "${env:ProgramFiles(x86)}\NVIDIA Corporation\Control Panel Client\nvcplui.exe") | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
                    if ($nvcpl) { try { Start-Process -FilePath $nvcpl; $out = @{ success=$true; message="$($names[$genre]) 추천 프로필을 저장했습니다. NVIDIA 제어판이 열렸습니다. 게임별 3D 설정을 확인하고 적용하세요." } } catch { $out = @{ success=$true; message="$($names[$genre]) 프로필은 저장했지만 NVIDIA 제어판을 자동으로 열지 못했습니다. 시작 메뉴에서 NVIDIA 제어판을 여세요." } } }
                    else { $out = @{ success=$true; message="$($names[$genre]) 추천 프로필을 저장했습니다. NVIDIA 제어판이 설치/검색되지 않았습니다. NVIDIA App 또는 드라이버 설치 상태를 확인하세요." } }
                }
            }
            $bytes = [System.Text.Encoding]::UTF8.GetBytes(($out | ConvertTo-Json -Compress)); $res.ContentType = 'application/json; charset=utf-8'; $res.ContentLength64 = $bytes.Length; $res.OutputStream.Write($bytes,0,$bytes.Length)
        }
        elseif ($req.Url.AbsolutePath -eq "/api/device-tools/open" -and $req.HttpMethod -eq "POST") {
            if ($req.ContentLength64 -gt 8192) { $res.StatusCode = 413; $out = @{ error = '요청이 너무 큽니다.' } }
            else {
                $reader = New-Object System.IO.StreamReader($req.InputStream, $req.ContentEncoding)
                try { $payload = $reader.ReadToEnd() | ConvertFrom-Json -ErrorAction Stop } finally { $reader.Dispose() }
                switch ([string]$payload.tool) {
                    'nvidia' { $paths = @("$env:ProgramFiles\NVIDIA Corporation\Control Panel Client\nvcplui.exe", "${env:ProgramFiles(x86)}\NVIDIA Corporation\Control Panel Client\nvcplui.exe"); $exe = $paths | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1; if ($exe) { Start-Process -FilePath $exe; $out=@{success=$true;message='NVIDIA 제어판을 열었습니다.'} } else { $res.StatusCode=404; $out=@{error='NVIDIA 제어판을 찾지 못했습니다. NVIDIA 드라이버 설치 여부를 확인하세요.'} } }
                    'display' { Start-Process 'ms-settings:display'; $out=@{success=$true;message='Windows 디스플레이 설정을 열었습니다.'} }
                    'audio' { Start-Process 'ms-settings:sound'; $out=@{success=$true;message='Windows 오디오 설정을 열었습니다.'} }
                    default { $res.StatusCode=400; $out=@{error='허용되지 않은 도구입니다.'} }
                }
            }
            $bytes = [System.Text.Encoding]::UTF8.GetBytes(($out | ConvertTo-Json -Compress)); $res.ContentType = 'application/json; charset=utf-8'; $res.ContentLength64 = $bytes.Length; $res.OutputStream.Write($bytes,0,$bytes.Length)
        }
        elseif ($req.Url.AbsolutePath -eq "/api/health" -and $req.HttpMethod -in @('GET','HEAD')) {
            $out = @{ success = $true; service = 'ServerService'; version = $script:AppVersion; pid = $PID; time = (Get-Date).ToString('o') }
            $bytes = [System.Text.Encoding]::UTF8.GetBytes(($out | ConvertTo-Json -Compress))
            $res.ContentType = 'application/json; charset=utf-8'; $res.ContentLength64 = $bytes.Length
            if ($req.HttpMethod -ne 'HEAD') { $res.OutputStream.Write($bytes,0,$bytes.Length) }
        }
        elseif ($req.Url.AbsolutePath -eq "/api/system") {
            Write-ServerLog 'GET /api/system: collection started'
            try {
                $data = Get-SystemData
                $json = ConvertTo-Json -InputObject $data -Depth 8 -Compress
                $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
                $res.StatusCode = 200
                $res.ContentType = "application/json; charset=utf-8"
                $res.ContentLength64 = $bytes.Length
                $res.OutputStream.Write($bytes, 0, $bytes.Length)
                Write-ServerLog ('GET /api/system: success (' + $bytes.Length + ' bytes)')
            } catch {
                $details = ($_ | Out-String).Trim()
                Write-ServerLog ('GET /api/system: collection failed: ' + $details)
                $payload = @{ error = '시스템 정보 수집에 실패했습니다.'; detail = $details } | ConvertTo-Json -Compress
                $bytes = [System.Text.Encoding]::UTF8.GetBytes($payload)
                $res.StatusCode = 500
                $res.ContentType = 'application/json; charset=utf-8'
                $res.ContentLength64 = $bytes.Length
                $res.OutputStream.Write($bytes, 0, $bytes.Length)
            }
        } else {
            $rel = [uri]::UnescapeDataString($req.Url.AbsolutePath.TrimStart('/'))
            if ([string]::IsNullOrWhiteSpace($rel)) { $rel = "index.html" }
            $normalized = $rel.Replace('\','/')
            $allowedStatic = @('index.html','app.js','audio-monitor.js','styles.css','assets/logo_256.png','assets/logo_48.png','assets/ServerService.ico')
            if ($normalized -notin $allowedStatic) { $res.StatusCode = 404; $res.Close(); continue }
            $path = [System.IO.Path]::GetFullPath((Join-Path $root $normalized.Replace('/', [IO.Path]::DirectorySeparatorChar)))
            $rootFull = [System.IO.Path]::GetFullPath($root).TrimEnd('\') + '\'
            if (-not $path.StartsWith($rootFull, [System.StringComparison]::OrdinalIgnoreCase)) {
                $res.StatusCode = 403
                $res.Close()
                continue
            }
            if (Test-Path $path -PathType Leaf) {
                $bytes = [System.IO.File]::ReadAllBytes($path)
                $res.ContentLength64 = $bytes.Length
                $ext = [System.IO.Path]::GetExtension($path).ToLower()
                $mime = switch ($ext) {
                    ".html" { "text/html; charset=utf-8" }
                    ".css" { "text/css; charset=utf-8" }
                    ".js" { "application/javascript; charset=utf-8" }
                    ".json" { "application/json; charset=utf-8" }
                    default { "application/octet-stream" }
                }
                $res.ContentType = $mime
                $res.OutputStream.Write($bytes, 0, $bytes.Length)
            } else {
                $res.StatusCode = 404
            }
        }
    } catch {
        $details = ($_ | Out-String).Trim()
        $pathText = if ($req -and $req.Url) { $req.Url.AbsolutePath } else { '<unknown>' }
        Write-ServerLog ("요청 오류 [$pathText]: $details")
        try {
            $res.StatusCode = 500
            $res.ContentType = 'application/json; charset=utf-8'
            $payload = @{ error = '서버에서 요청을 처리하지 못했습니다.'; detail = $details }
            $bytes = [System.Text.Encoding]::UTF8.GetBytes(($payload | ConvertTo-Json -Compress))
            $res.ContentLength64 = $bytes.Length
            $res.OutputStream.Write($bytes,0,$bytes.Length)
        } catch {}
    }
    try { $res.Close() } catch {}
}
