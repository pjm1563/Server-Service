﻿$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$isccCandidates = @(
  "$env:ProgramFiles(x86)\Inno Setup 6\ISCC.exe",
  "$env:ProgramFiles\Inno Setup 6\ISCC.exe"
)
$iscc = $isccCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $iscc) {
  Write-Host "Inno Setup 6 is required to build the Windows installer."
  Write-Host "Install it from https://jrsoftware.org/isinfo.php, then run this script again."
  exit 1
}
Push-Location $root
try {
  & $iscc "ServerService.iss"
  if ($LASTEXITCODE -ne 0) { throw "Inno Setup build failed: $LASTEXITCODE" }
  Write-Host "Installer created at: $root\dist\ServerService_Setup.exe"
} finally {
  Pop-Location
}
