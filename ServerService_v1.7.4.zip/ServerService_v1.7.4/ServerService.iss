#define MyAppName "ServerService"
#define MyAppVersion "1.7.4"
#define MyAppPublisher "ServerService"

[Setup]
AppId={{9A6B9C4E-72F1-4D6E-9D12-5A1200000001}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\ServerService
DefaultGroupName={#MyAppName}
OutputDir=dist
OutputBaseFilename=ServerService_Setup
SetupIconFile=assets\ServerService.ico
UninstallDisplayIcon={app}\assets\ServerService.ico
ArchitecturesInstallIn64BitMode=x64
PrivilegesRequired=admin
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
CloseApplications=yes

[Files]
Source: "*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs; Excludes: "dist\*,*.iss,build-installer.ps1"

[Icons]
Name: "{group}\ServerService"; Filename: "{cmd}"; Parameters: "/c """"{app}\start.bat"""""; WorkingDir: "{app}"; IconFilename: "{app}\assets\ServerService.ico"
Name: "{autodesktop}\ServerService"; Filename: "{cmd}"; Parameters: "/c """"{app}\start.bat"""""; WorkingDir: "{app}"; IconFilename: "{app}\assets\ServerService.ico"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "바탕 화면 바로가기 만들기"; GroupDescription: "추가 바로가기:"; Flags: checkedonce

[Run]
Filename: "{cmd}"; Parameters: "/c """"{app}\start.bat"""""; WorkingDir: "{app}"; Description: "ServerService 실행"; Flags: postinstall nowait skipifsilent
