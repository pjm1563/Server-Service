﻿ServerService extension package inbox (Uploads) - v1.6.4

1) Copy extension ZIP files directly into this folder. Do not put them in Downloads.
2) Refresh the extension list in ServerService to validate the package.
3) Packages passing validation are registered and copied to the sibling Downloads folder.
4) Registration only validates and catalogs the ZIP; it does not execute the extension code.


10. v1.6.4 디스크 용량 계산 오류 수정
- Windows 디스크 용량처럼 32비트 정수 범위를 초과하는 값에 대해 [math]::Max()가 Int32 변환 오류를 내던 문제를 수정했습니다. 바이트/실수 계산의 Max/Min 인수 형식을 명시해 /api/system 응답이 반복 실패하지 않도록 했습니다.
- 이 환경에서 Windows PowerShell 실기 실행 검증은 수행하지 못했으므로, 실행 후 server.log에서 /api/system 오류가 사라졌는지 확인하세요.
