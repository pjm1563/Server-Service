(() => {
  "use strict";
  class AudioMonitor {
    constructor(root) {
      this.root = root; this.stream = null; this.context = null; this.analyser = null;
      this.source = null; this.raf = 0; this.muted = false; this.running = false;
      this.threshold = -35; this.deviceId = ""; this.options = { echoCancellation: true, noiseSuppression: true, autoGainControl: true }; this.displayGain = 1;
      this.wave = root.querySelector('[data-audio="wave"]'); this.spectrum = root.querySelector('[data-audio="spectrum"]');
      this.bind(); this.refreshDevices(); this.paintIdle();
      this.themeObserver = new MutationObserver(() => { if (!this.running) this.paintIdle(); });
      this.themeObserver.observe(document.body, { attributes: true, attributeFilter: ["data-theme"] });
    }
    q(name) { return this.root.querySelector(`[data-audio="${name}"]`); }
    setStatus(text) { const el = this.q("status"); if (el) el.textContent = text; }
    setState(text, active = false) { const el = this.q("state"); if (el) { el.textContent = text; el.classList.toggle("active", active); } }
    canvasPalette() {
      const style = getComputedStyle(document.body);
      return {
        background: style.getPropertyValue("--panel-2").trim() || "#151f2e",
        grid: style.getPropertyValue("--border").trim() || "#243144",
        wave: style.getPropertyValue("--cyan").trim() || "#55c9e9"
      };
    }
    bind() {
      this.q("start")?.addEventListener("click", () => this.start());
      this.q("stop")?.addEventListener("click", () => this.stop());
      this.q("mute")?.addEventListener("click", () => this.toggleMute());
      this.q("device")?.addEventListener("change", async e => { this.deviceId = e.target.value; if (this.running) { await this.stop(false); await this.start(); } });
      this.q("threshold")?.addEventListener("input", e => { this.threshold = Number(e.target.value); const label = this.q("threshold-label"); if (label) label.textContent = `${this.threshold} dBFS`; });
      for (const [key, name] of [["echo", "echoCancellation"], ["noise", "noiseSuppression"], ["agc", "autoGainControl"]]) this.q(key)?.addEventListener("change", async e => { this.options[name] = e.target.checked; if (this.running) { await this.stop(false); await this.start(); } });
      this.q("gain")?.addEventListener("input", e => { this.displayGain = Number(e.target.value) / 100; const label = this.q("gain-label"); if (label) label.textContent = `${e.target.value}%`; });
      this.threshold = Number(this.q("threshold")?.value || -35);
      this.displayGain = Number(this.q("gain")?.value || 100) / 100;
      this.options.echoCancellation = this.q("echo")?.checked ?? true; this.options.noiseSuppression = this.q("noise")?.checked ?? true; this.options.autoGainControl = this.q("agc")?.checked ?? true;
    }
    async refreshDevices() {
      const select = this.q("device"); if (!select || !navigator.mediaDevices?.enumerateDevices) return;
      try {
        const devices = await navigator.mediaDevices.enumerateDevices();
        const previous = this.deviceId || select.value;
        select.replaceChildren();
        const def = document.createElement("option"); def.value = ""; def.textContent = "기본 마이크"; select.appendChild(def);
        devices.filter(d => d.kind === "audioinput").forEach((d, i) => { const o = document.createElement("option"); o.value = d.deviceId; o.textContent = d.label || `마이크 ${i + 1}`; select.appendChild(o); });
        if ([...select.options].some(o => o.value === previous)) select.value = previous;
      } catch (_) { this.setStatus("마이크 장치 목록을 읽을 수 없습니다. 브라우저 권한을 확인하세요."); }
    }
    async start() {
      if (this.running) return;
      if (!navigator.mediaDevices?.getUserMedia) { this.setStatus("이 환경에서는 마이크 접근을 지원하지 않습니다. localhost 또는 확장프로그램 화면에서 실행하세요."); return; }
      this.setStatus("마이크 권한을 확인하는 중…");
      try {
        const selected = this.q("device")?.value || this.deviceId;
        const audioOptions = { echoCancellation: this.options.echoCancellation, noiseSuppression: this.options.noiseSuppression, autoGainControl: this.options.autoGainControl };
        let constraints = { audio: selected ? { deviceId: { exact: selected }, ...audioOptions } : audioOptions, video: false };
        try { this.stream = await navigator.mediaDevices.getUserMedia(constraints); }
        catch (err) { if (!selected) throw err; this.stream = await navigator.mediaDevices.getUserMedia({ audio: { deviceId: { exact: selected }, ...audioOptions }, video: false }); }
        this.context = new (window.AudioContext || window.webkitAudioContext)();
        if (this.context.state === "suspended") await this.context.resume();
        this.analyser = this.context.createAnalyser(); this.analyser.fftSize = 2048; this.analyser.smoothingTimeConstant = 0.72;
        this.source = this.context.createMediaStreamSource(this.stream); this.source.connect(this.analyser);
        this.running = true; this.muted = false; this.stream.getAudioTracks().forEach(t => t.enabled = true);
        this.q("start").disabled = true; this.q("stop").disabled = false; this.q("mute").disabled = false; this.q("mute").textContent = "마이크 캡처 음소거";
        this.setState("모니터링 중", true); this.setStatus(`마이크 입력을 로컬에서 분석 중입니다. 에코 제거 ${this.options.echoCancellation ? "켜짐" : "꺼짐"}. 오디오는 저장·전송하지 않습니다.`);
        await this.refreshDevices(); this.draw();
      } catch (err) {
        this.cleanup(); this.setState("중지됨", false);
        const messages = { NotAllowedError: "마이크 권한이 거부되었습니다. 브라우저 사이트 권한에서 마이크를 허용하세요.", NotFoundError: "사용 가능한 마이크를 찾지 못했습니다.", NotReadableError: "마이크를 다른 앱이 사용 중이거나 장치에 접근할 수 없습니다.", OverconstrainedError: "선택한 마이크를 사용할 수 없습니다. 다른 장치를 선택하세요." };
        this.setStatus(messages[err.name] || `오디오 시작 실패: ${err.message || err.name}`);
      }
    }
    toggleMute() {
      if (!this.stream) return;
      this.muted = !this.muted; this.stream.getAudioTracks().forEach(t => t.enabled = !this.muted);
      this.q("mute").textContent = this.muted ? "마이크 캡처 음소거 해제" : "마이크 캡처 음소거";
      this.setStatus(this.muted ? "이 모듈의 마이크 캡처가 음소거되었습니다. Windows 전체 설정은 변경되지 않습니다." : "마이크 입력을 로컬에서 분석 중입니다.");
    }
    async stop(showStatus = true) {
      this.cleanup(); this.running = false; this.muted = false;
      if (this.q("start")) this.q("start").disabled = false;
      if (this.q("stop")) this.q("stop").disabled = true;
      if (this.q("mute")) { this.q("mute").disabled = true; this.q("mute").textContent = "마이크 캡처 음소거"; }
      this.setState("중지됨", false); this.paintIdle();
      if (showStatus) this.setStatus("모니터링이 중지되었습니다.");
      await this.refreshDevices();
    }
    cleanup() {
      if (this.raf) cancelAnimationFrame(this.raf); this.raf = 0;
      if (this.source) { try { this.source.disconnect(); } catch (_) {} } this.source = null;
      if (this.stream) this.stream.getTracks().forEach(t => t.stop()); this.stream = null;
      if (this.context) { this.context.close().catch(() => {}); } this.context = null; this.analyser = null;
    }
    paintIdle() {
      const palette = this.canvasPalette();
      for (const canvas of [this.wave, this.spectrum]) if (canvas) { const c = canvas.getContext("2d"); c.clearRect(0,0,canvas.width,canvas.height); c.fillStyle = palette.background; c.fillRect(0,0,canvas.width,canvas.height); c.strokeStyle = palette.grid; c.beginPath(); c.moveTo(0,canvas.height/2); c.lineTo(canvas.width,canvas.height/2); c.stroke(); }
      const meter = this.q("meter"); if (meter) meter.style.width = "0%";
      const db = this.q("db"); if (db) db.textContent = "−∞ dBFS";
      const rms = this.q("rms"); if (rms) rms.textContent = "0%";
      const peak = this.q("peak"); if (peak) peak.textContent = "0%";
      const det = this.q("detection"); if (det) det.classList.remove("detected");
      if (this.q("detection-title")) this.q("detection-title").textContent = "소리 감지 대기";
      if (this.q("detection-copy")) this.q("detection-copy").textContent = "모니터링을 시작하면 입력 소리를 분석합니다.";
    }
    draw() {
      if (!this.running || !this.analyser) return;
      const n = this.analyser.fftSize, wave = new Uint8Array(n), freq = new Uint8Array(this.analyser.frequencyBinCount);
      this.analyser.getByteTimeDomainData(wave); this.analyser.getByteFrequencyData(freq);
      let sum = 0, peak = 0;
      for (let i=0;i<n;i++) { const v=(wave[i]-128)/128; sum += v*v; peak = Math.max(peak,Math.abs(v)); }
      const rms = Math.sqrt(sum/n), rawDb = rms > 0 ? 20*Math.log10(rms) : -Infinity;
      const displayRms = Math.min(1, rms * this.displayGain), db = rawDb;
      const pct = Math.min(100,Math.round(displayRms*100*2.5)), peakPct=Math.min(100,Math.round(Math.min(1, peak * this.displayGain)*100));
      if (this.q("db")) this.q("db").textContent = Number.isFinite(db) ? `${db.toFixed(1)} dBFS` : "−∞ dBFS";
      if (this.q("rms")) this.q("rms").textContent = `${pct}%`;
      if (this.q("peak")) this.q("peak").textContent = `${peakPct}%`;
      if (this.q("meter")) this.q("meter").style.width = `${pct}%`;
      const meterWrap=this.root.querySelector('[role="meter"]'); if(meterWrap) meterWrap.setAttribute("aria-valuenow",String(pct));
      const detected = !this.muted && db > this.threshold;
      const detection=this.q("detection"); if(detection) detection.classList.toggle("detected",detected);
      if (this.q("detection-title")) this.q("detection-title").textContent = detected ? "소리 감지됨" : "조용함";
      if (this.q("detection-copy")) this.q("detection-copy").textContent = detected ? `입력 ${db.toFixed(1)} dBFS · 임계값 ${this.threshold} dBFS 초과` : `현재 ${Number.isFinite(db)?db.toFixed(1):"−∞"} dBFS · 임계값 ${this.threshold} dBFS`;
      this.paintWave(wave); this.paintSpectrum(freq); this.raf=requestAnimationFrame(()=>this.draw());
    }
    paintWave(data) {
      if (!this.wave) return; const palette=this.canvasPalette(), c=this.wave.getContext("2d"), w=this.wave.width,h=this.wave.height; c.clearRect(0,0,w,h); c.fillStyle=palette.background;c.fillRect(0,0,w,h);c.strokeStyle=palette.grid;c.lineWidth=1;c.beginPath();c.moveTo(0,h/2);c.lineTo(w,h/2);c.stroke();c.strokeStyle=palette.wave;c.lineWidth=2;c.beginPath();
      for(let i=0;i<data.length;i++){const x=i/(data.length-1)*w,y=data[i]/255*h;if(i===0)c.moveTo(x,y);else c.lineTo(x,y);}c.stroke();
    }
    paintSpectrum(data) {
      if (!this.spectrum) return; const palette=this.canvasPalette(), c=this.spectrum.getContext("2d"),w=this.spectrum.width,h=this.spectrum.height;c.clearRect(0,0,w,h);c.fillStyle=palette.background;c.fillRect(0,0,w,h);const bars=64,step=Math.max(1,Math.floor(data.length/bars)),gap=3,bw=w/bars;
      for(let i=0;i<bars;i++){let v=0;for(let j=0;j<step;j++)v=Math.max(v,data[i*step+j]||0);const bh=v/255*(h-12);c.fillStyle=`hsl(${195-i*1.6} 78% 62%)`;c.fillRect(i*bw+gap/2,h-bh,bw-gap,bh);}
    }
  }
  window.ServerServiceAudioMonitor = AudioMonitor;
  const init = () => document.querySelectorAll('[data-audio-monitor]').forEach(root => { if (!root.__audioMonitor) root.__audioMonitor = new AudioMonitor(root); });
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init, { once: true }); else init();
})();
